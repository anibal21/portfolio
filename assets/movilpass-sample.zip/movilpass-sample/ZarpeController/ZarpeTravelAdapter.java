package com.autumnideas.myapplication.controllers;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.autumnideas.myapplication.R;
import com.autumnideas.myapplication.db.DBHelper;
import com.autumnideas.myapplication.db.DBzarpado;
import com.autumnideas.myapplication.ui.Recogida.R_PassengerDetailActivity;
import com.autumnideas.myapplication.ui.Zarpe.Z_PassengersActivity;
import com.autumnideas.myapplication.ui.Zarpe.Z_ValorActivity;
import com.autumnideas.myapplication.utils.GPS_Listener;
import com.autumnideas.myapplication.utils.ZarpePassenger;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ZarpeTravelAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private ArrayList<ZarpePassenger> data;
    String user_position;
    String user_id;
    String id_zarpe;
    double user_latitude;
    double user_longitude;
    Activity activity;
    JSONObject obj;
    JSONArray jsonArray;
    ArrayList<String> rutsListos;
    String hora_empieza;
    private Dialog dialog;
    CardView dialogButton;
    EditText dialogInput;
    int insertValue;
    String DBValue;

    //Variables GPS
    private FusedLocationProviderClient mFusedLocationClient;
    private static final int ACCESS_COARSE_LOCATION_CODE = 1;
    static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;
    LocationListener locationListener;

    // Constructor de la clase
    public ZarpeTravelAdapter(Context context, int layout, ArrayList<ZarpePassenger> data, String user_id, Activity activity, JSONObject obj, JSONArray jsonArray, String id_zarpe, ArrayList<String> rutsListos, LocationManager locationManager, LocationListener locationListener, String hora_empieza) {
        this.context = context;
        this.layout = layout;
        this.data = data;
        this.user_id = user_id;
        this.activity = activity;
        this.obj = obj;
        this.jsonArray = jsonArray;
        this.id_zarpe = id_zarpe;
        this.rutsListos = rutsListos;
        this.locationManager = locationManager;
        this.locationListener = locationListener;
        this.hora_empieza = hora_empieza;
    }

    @Override
    public int getCount() {
        return this.data.size();
    }

    @Override
    public Object getItem(int position) {
        return this.data.get(position);
    }

    @Override
    public long getItemId(int id) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        // Copiamos vista
        View v = convertView;

        // Inflamos vista que ha llegado con el layout personalizado
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        v = layoutInflater.inflate(R.layout.card_z_passenger_travel, null);

        // Referenciamos el elemento a moificar y lo rellenamos
        TextView number = (TextView) v.findViewById(R.id.card_zarpe_tv_passenger_travel_rut);
        number.setText(data.get(position).getName());
        TextView address = v.findViewById(R.id.card_zarpe_tv_passenger_address);
        if(data.get(position).getAddress().equals("null")){
            address.setText("Sin dirección asignada");
        }
        else{
            address.setText(data.get(position).getAddress());
        }

        TextView icon1 = v.findViewById(R.id.card_zarpe_tv_passenger_travel_textbajar);
        icon1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    bajarPasajero(position);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        ConstraintLayout icon2 = v.findViewById(R.id.card_zarpe_tv_passenger_travel_layoutbajar);
        icon2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final LocationManager manager = (LocationManager) context.getSystemService( Context.LOCATION_SERVICE );
                try {
                    if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
                        Toast.makeText(context, "GPS desactivado. Activelo para continuar", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        bajarPasajero(position);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });


        // Para filtrar que sea un pasajero desconocido
        if (data.get(position).getStatus().equals("2")) {
            v.setBackgroundResource(R.color.colorAccent);
        }

        // Devolvemos la vista inflada y modificada con nuestros datos
        return v;
    }

    public void stopGPS(){
        locationManager.removeUpdates(locationListener);
        locationManager = null;
    }

    public void bajarPasajero(final int position) throws JSONException {

        if ( !locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            Toast.makeText(context, "GPS desactivado. Activelo para continuar", Toast.LENGTH_SHORT).show();
        }
        else{
            if(data.size()>0){
                insertValue = 0;
                dialog = new Dialog(context);
                dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
                dialog.getWindow().setBackgroundDrawableResource(R.drawable.rounded_dialog);
                dialog.setCanceledOnTouchOutside(true);

                // custom dialog
                dialog.setContentView(R.layout.dialog_z_addpassenger);
                dialogButton = dialog.findViewById(R.id.addpassenger_verify_rut_card);
                dialogInput = dialog.findViewById(R.id.addpassenger_rut_field);

                DBValue = data.get(position).getTarifa();

                Log.e("TREMENDO!", DBValue);

                if(DBValue.equals("-1")){
                    dialogInput.setEnabled(true);
                }else{
                    dialogInput.setText(DBValue);
                    dialogInput.setEnabled(false);
                }

                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(dialogInput.getText().toString().equals("")){
                            insertValue = 0;
                        }else{
                            insertValue = Integer.valueOf(dialogInput.getText().toString());
                        }
                        DateFormat df = new SimpleDateFormat("HH:mm:ss");
                        String date = df.format(Calendar.getInstance().getTime());

                        obj = new JSONObject();
                        try {
                            obj.put("rut", data.get(position).getRut())
                                    .put("latitud", GPS_Listener.getGps_latitude())
                                    .put("longitud", GPS_Listener.getGps_longitude())
                                    .put("tarifa", String.valueOf(insertValue))
                                    .put("hora_realiza", date);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        jsonArray.put(obj);

                        Log.e("obj", String.valueOf(obj));

                        data.remove(position);
                        notifyDataSetChanged();

                        if (data.isEmpty()) {
                            stopGPS();
                            Intent intent = new Intent(context, Z_ValorActivity.class);
                            intent.putExtra("id_user", user_id);
                            intent.putExtra("id_zarpe", id_zarpe);
                            intent.putExtra("jsonArray", jsonArray.toString());
                            intent.putExtra("rutsListos", rutsListos);
                            intent.putExtra("hora_empieza", hora_empieza);
                            ((Activity) context).finish();
                            context.startActivity(intent);
                        }
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        }

    }
}

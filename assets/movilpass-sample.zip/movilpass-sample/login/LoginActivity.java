package com.autumnideas.myapplication.ui;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.autumnideas.myapplication.R;
import com.autumnideas.myapplication.db.DBHelper;
import com.autumnideas.myapplication.db.DBmovil;
import com.autumnideas.myapplication.ui.Recogida.R_PassengerDetailActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class LoginActivity extends AppCompatActivity {

    Boolean status;
    EditText user_et, password_et;
    String login_status, id_user;
    Button login_button;
    ProgressDialog progressDialog;
    DBHelper db;

    //region Metodos Botones

    public void loginButton(){
        final LocationManager locationManager = (LocationManager) this.getSystemService( Context.LOCATION_SERVICE );

        if(isNetworkAvailable()){
            if ( !locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
                Toast.makeText(this, "GPS desactivado. Activelo para continuar", Toast.LENGTH_SHORT).show();
            }
            else{
                LoadProfileRequest load = new LoadProfileRequest(user_et.getText().toString(),password_et.getText().toString(), this);
                load.execute();
            }
        }
        else{
            Toast.makeText(this, "No se detectó conexión a internet", Toast.LENGTH_SHORT).show();
        }
    }
    //endregion

    //region Validaciones
    public boolean check_User (){
        String user_text = user_et.getText().toString();

        if(user_text.isEmpty()) {

            Toast.makeText(this, "Ingrese nombre de usuario", Toast.LENGTH_SHORT).show();
            return (false);
        }
        return true;
    }

    public boolean check_Password (){
        String pass_text = password_et.getText().toString();

        if(pass_text.isEmpty()) {

            Toast.makeText(this, "Ingrese constraseña", Toast.LENGTH_SHORT).show();
            return (false);
        }
        else{
            return true;
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    //endregion

    //region REQUEST ASYNCTASK
    public class LoadProfileRequest extends AsyncTask<Void, Void, Void> {
        private static final String SERVER_URL_REQUEST_LOGIN ="http://passenger.dis-patcher.cl/login.php" ;
        private final String USER_AGENT = "Mozilla/5.0";
        private String user = "";
        private String password = "";
        private String json_decoded = "";
        private Context context;
        private String id_mobile;
        private String id_company;
        private String mobile_name;

        public LoadProfileRequest(String user, String password, Context context) {
            this.user = user;
            this.password = password;
            this.context = context;
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                this.json_decoded = POST(SERVER_URL_REQUEST_LOGIN, "username=" + this.user + "&password=" + password);
            } catch (IOException e) {
                e.printStackTrace();
            }
            //Log.e("Json Decoded: ",json_decoded);
            String jsonString = this.json_decoded;

            JSONObject allObj = null;

            try {
                allObj = new JSONObject(jsonString);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                login_status = allObj.getString("success");
                id_user = allObj.getString("id_chofer");
                id_mobile = allObj.getString("id_mobile");
                mobile_name = allObj.getString("name");
                id_company = allObj.getString("id_company");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        private String POST(String url, String urlParameters) throws IOException {
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            //add reuqest header
            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

            //String urlParameters = "sn=C02G8416DRJM&cn=&locale=&caller=&num=12345";

            // Send post request
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result
            return (response.toString());
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if(check_User() && check_Password()){
                progressDialog = new ProgressDialog(context);
                progressDialog.setMax(100);
                progressDialog.setMessage("Cargando credenciales...");
                progressDialog.show();
            }
            else{
                this.cancel(true);
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);


            if(check_User() && check_Password()){
                if(login_status.equals("true")){
                    //Primero definiremos la el siguiente paso
                    Intent intent = new Intent(LoginActivity.this, OptionSelectActivity.class);
                    intent.putExtra("id_user", id_user);

                    //Finalmente actualizamos credenciales
                    DBmovil dBmovil = new DBmovil(this.mobile_name,this.id_mobile,this.id_company);
                    db.createMovil(dBmovil);

                    //Codigo que sube los cambios y posteriormente baja lo actualizado
                    try {
                        db.pushData(LoginActivity.this, true , intent);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                else{
                    Toast.makeText(context, "Usuario o contraseña invalidos", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }
        }
    }
    //endregion

    //region Permisos
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED
                        ) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(LoginActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
    //endregion

    //region onCreate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(LoginActivity.this,
                new String[]{
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                },
                1);

        db = new DBHelper(getApplicationContext());


        user_et = findViewById(R.id.la_iUsername);
        password_et = findViewById(R.id.la_iPassword);
        login_button = findViewById(R.id.la_bSubmit);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginButton();
            }
        });
    }
    //endregion

}

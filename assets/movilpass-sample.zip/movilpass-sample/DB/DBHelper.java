package com.autumnideas.myapplication.db;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.widget.Toast;

import com.autumnideas.myapplication.ui.LoginActivity;
import com.autumnideas.myapplication.utils.ZarpePassenger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DBHelper extends SQLiteOpenHelper {

    ProgressDialog progressDialogWithContext;

    // Logcat tag
    private static final String LOG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "sodexo";

    // Table Names
    private static final String TABLE_MOVIL = "movil";
    private static final String TABLE_RUTA_RECOGIDA = "ruta_recogida";
    private static final String TABLE_RECOGIDA = "recogida";
    private static final String TABLE_RUTA_ZARPE = "ruta_zarpe";
    private static final String TABLE_ZARPADO = "zarpado";
    private static final String TABLE_PASAJERO = "pasajero";


    // Common column names
    private static final String KEY_STATUS = "status";

    // USER Table - column names
    private static final String NAME = "name";
    private static final String ID_MOBILE = "id_mobile";
    private static final String ID_COMPANY = "id_company";
    private static final String URL_FOTO = "url_foto";
    private static final String TIPO_PASAJERO = "tipo_pasajero";


    private static final String ID = "id";
    private static final String NOMBRE_RECOGIDA = "nombre_recogida";
    //--id_mobile definida      en linea 27--
    private static final String ID_CLIENTE = "id_cliente";
    private static final String FECHA_PROGRAMA = "fecha_programa";
    private static final String HORA_PROGRAMA = "hora_programa";
    private static final String HORA_REALIZA = "hora_realiza";
    private static final String VALOR = "valor";
    private static final String DETALLE = "detalle";
    private static final String ESTADO = "estado";
    private static final String HORA_TERMINA = "hora_termina";
    private static final String ID_EMPRESA = "id_empresa";
    private static final String RUT = "rut";

    //--id definida             en linea 30
    private static final String DIRECCION = "direccion";
    private static final String ID_PASAJERO = "id_pasajero";
    //--fecha_programa definida en linea 34
    //--hora_programa definida  en liena 35
    //--hora_realiza definida   en linea 36
    private static final String ID_RUTA_RECOGIDA = "id_ruta_recogida";
    //--id_cliente definida     en linea 33
    //--estado definido         en linea 39
    //--detalle definido        en linea 38
    private static final String LATITUD = "latitud";
    private static final String LONGITUD = "longitud";
    private static final String NOMBRE = "nombre";
    private static final String TELEFONO = "telefono";
    private static final String DIRECCION2 = "direccion2";
    private static final String ID_CANCEL = "id_cancel";

    //--id definida             en linea 30
    //--direccion definida      en linea 44
    //--id_mobile definida      en liena 27
    //--id_cliente definida     en linea 33
    //--fecha_programa definida en linea 34
    //--hora_programa definida  en liena 35
    //--hora_realiza definida   en linea 36
    //--valor definida          en linea 37
    //--detalle definido        en linea 38
    //--estado definido         en linea 39
    //--id_empresa              en linea 41

    //--id definida             en linea 30
    private static final String ID_RUTA_ZARPE = "id_ruta_zarpe";
    //--id_pasajero definida    en linea 45
    //--hora_realiza definida   en linea 36
    //--hora_programa definida  en liena 35
    //--fecha_programa definida en linea 34
    private static final String HORA_BAJADA = "hora_bajada";
    //--latitud definida        en linea 53
    //--longitud definida       en linea 54
    //--detalle definido        en linea 38
    //--id_cliente              en linea 33
    //--estado                  en linea 39

    // USER table create statement
    private static final String CREATE_TABLE_MOVIL = "CREATE TABLE " + TABLE_MOVIL
            + "(" + NAME + " TEXT," +
            ID_MOBILE + " TEXT PRIMARY KEY," +
            ID_COMPANY + " TEXT)";

    private static final String CREATE_TABLE_RUTA_RECOGIDA = "CREATE TABLE " + TABLE_RUTA_RECOGIDA
            + "(" + ID + " TEXT PRIMARY KEY," +
            NOMBRE_RECOGIDA + " TEXT," +
            ID_MOBILE + " TEXT," +
            ID_CLIENTE + " TEXT," +
            FECHA_PROGRAMA + " TEXT," +
            HORA_PROGRAMA + " TEXT," +
            HORA_REALIZA + " TEXT," +
            VALOR + " TEXT," +
            DETALLE + " TEXT," +
            ESTADO + " TEXT," +
            HORA_TERMINA + " TEXT," +
            ID_EMPRESA + " TEXT)";

    private static final String CREATE_TABLE_RECOGIDA = "CREATE TABLE " + TABLE_RECOGIDA
            + "(" + ID + " TEXT PRIMARY KEY," +
            ID_MOBILE + " TEXT," +
            DIRECCION + " TEXT," +
            NOMBRE + " TEXT," +
            ID_PASAJERO + " TEXT," +
            FECHA_PROGRAMA + " TEXT," +
            HORA_PROGRAMA + " TEXT," +
            HORA_REALIZA + " TEXT," +
            ID_RUTA_RECOGIDA + " TEXT," +
            ID_CLIENTE + " TEXT," +
            ESTADO + " TEXT," +
            DETALLE + " TEXT," +
            LATITUD + " TEXT," +
            LONGITUD + " TEXT," +
            TELEFONO + " TEXT," +
            DIRECCION2 + " TEXT," +
            VALOR + " TEXT," +
            ID_CANCEL + " TEXT)";

    private static final String CREATE_TABLE_RUTA_ZARPE = "CREATE TABLE " + TABLE_RUTA_ZARPE
            + "(" + ID + " TEXT PRIMARY KEY," +
            DIRECCION + " TEXT," +
            ID_MOBILE + " TEXT," +
            ID_CLIENTE + " TEXT," +
            FECHA_PROGRAMA + " TEXT," +
            HORA_PROGRAMA + " TEXT," +
            HORA_REALIZA + " TEXT," +
            VALOR + " TEXT," +
            DETALLE + " TEXT," +
            ESTADO + " TEXT," +
            ID_EMPRESA + " TEXT)";

    private static final String CREATE_TABLE_ZARPADO = "CREATE TABLE " + TABLE_ZARPADO
            + "(" + ID + " TEXT PRIMARY KEY," +
            ID_RUTA_ZARPE + " TEXT," +
            ID_PASAJERO + " TEXT," +
            HORA_REALIZA + " TEXT," +
            HORA_PROGRAMA + " TEXT," +
            FECHA_PROGRAMA + " TEXT," +
            HORA_BAJADA + " TEXT," +
            LATITUD + " TEXT," +
            LONGITUD + " TEXT," +
            DETALLE + " TEXT," +
            ID_CLIENTE + " TEXT," +
            VALOR + " TEXT," +
            ESTADO + " TEXT)";

    private static final String CREATE_TABLE_PASAJERO = "CREATE TABLE " + TABLE_PASAJERO
            + "(" + ID_PASAJERO + " TEXT PRIMARY KEY," +
            ID_COMPANY + " TEXT," +
            URL_FOTO + " TEXT," +
            TIPO_PASAJERO + " TEXT," +
            NOMBRE + " TEXT," +
            DIRECCION + " TEXT)";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // creating required tables
        db.execSQL(CREATE_TABLE_MOVIL);
        db.execSQL(CREATE_TABLE_RUTA_RECOGIDA);
        db.execSQL(CREATE_TABLE_RECOGIDA);
        db.execSQL(CREATE_TABLE_RUTA_ZARPE);
        db.execSQL(CREATE_TABLE_ZARPADO);
        db.execSQL(CREATE_TABLE_PASAJERO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // on upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOVIL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RUTA_RECOGIDA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECOGIDA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RUTA_ZARPE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ZARPADO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PASAJERO);


        // create new tables
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db){
        db.setForeignKeyConstraintsEnabled(true);
    }

    //region Create

    public long createMovil(DBmovil movil) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME, movil.getName());
        values.put(ID_MOBILE, movil.getId_mobile());
        values.put(ID_COMPANY, movil.getId_company());

        //Get Erase others users
        db.execSQL("delete from "+ TABLE_MOVIL);

        // insert row
        long user_response = db.insert(TABLE_MOVIL, null, values);

        return user_response;
    }

    public long createRuta_recogida(DBruta_recogida ruta_recogida) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, ruta_recogida.getId());
        values.put(NOMBRE_RECOGIDA, ruta_recogida.getNombre_recogida());
        values.put(ID_MOBILE, ruta_recogida.getId_mobile());
        values.put(ID_CLIENTE, ruta_recogida.getId_cliente());
        values.put(FECHA_PROGRAMA, ruta_recogida.getFecha_programa());
        values.put(HORA_PROGRAMA, ruta_recogida.getHora_programa());
        values.put(HORA_REALIZA, ruta_recogida.getHora_realiza());
        values.put(VALOR, ruta_recogida.getValor());
        values.put(DETALLE, ruta_recogida.getDetalle());
        values.put(ESTADO, ruta_recogida.getEstado());
        values.put(HORA_TERMINA, ruta_recogida.getHora_termina());
        values.put(ID_EMPRESA, ruta_recogida.getId_empresa());

        //Get Erase others users
//        db.execSQL("delete from "+ TABLE_RUTA_RECOGIDA);

        // insert row
        long user_response = db.insert(TABLE_RUTA_RECOGIDA, null, values);

        return user_response;
    }

    public long createRecogida(DBrecogida recogida) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, recogida.getId());
        values.put(ID_MOBILE, recogida.getId_movil());
        values.put(DIRECCION, recogida.getDireccion());
        values.put(ID_PASAJERO, recogida.getId_pasajero());
        values.put(NOMBRE, recogida.getNombre());
        values.put(FECHA_PROGRAMA, recogida.getFecha_programa());
        values.put(HORA_PROGRAMA, recogida.getHora_programa());
        values.put(HORA_REALIZA, recogida.getHora_realiza());
        values.put(ID_RUTA_RECOGIDA, recogida.getId_ruta_recogida());
        values.put(ID_CLIENTE, recogida.getId_cliente());
        values.put(ESTADO, recogida.getEstado());
        values.put(DETALLE, recogida.getDetalle());
        values.put(LATITUD, recogida.getLatitud());
        values.put(LONGITUD, recogida.getLongitud());
        values.put(TELEFONO, recogida.getTelefono());
        values.put(DIRECCION2, recogida.getDireccion2());
        values.put(VALOR, recogida.getValor());
        values.put(ID_CANCEL, recogida.getId_cancel());

        //Get Erase others users
//        db.execSQL("delete from "+ TABLE_RECOGIDA);

        // insert row
        long user_response = db.insert(TABLE_RECOGIDA, null, values);

        return user_response;
    }

    public long createRuta_zarpe(DBruta_zarpe ruta_zarpe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, ruta_zarpe.getId());
        values.put(DIRECCION, ruta_zarpe.getDireccion());
        values.put(ID_MOBILE, ruta_zarpe.getId_mobile());
        values.put(ID_CLIENTE, ruta_zarpe.getId_cliente());
        values.put(FECHA_PROGRAMA, ruta_zarpe.getFecha_programa());
        values.put(HORA_PROGRAMA, ruta_zarpe.getHora_programa());
        values.put(HORA_REALIZA, ruta_zarpe.getHora_realiza());
        values.put(VALOR, ruta_zarpe.getValor());
        values.put(DETALLE, ruta_zarpe.getDetalle());
        values.put(ESTADO, ruta_zarpe.getEstado());
        values.put(ID_EMPRESA, ruta_zarpe.getId_empresa());

        //Get Erase others users
//        db.execSQL("delete from "+ TABLE_RUTA_ZARPE);

        // insert row
        long user_response = db.insert(TABLE_RUTA_ZARPE, null, values);

        return user_response;
    }

    public long createZarpado(DBzarpado zarpado) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, zarpado.getId());
        values.put(ID_RUTA_ZARPE, zarpado.getId_ruta_zarpe());
        values.put(ID_PASAJERO, zarpado.getId_pasajero());
        values.put(HORA_REALIZA, zarpado.getHora_realiza());
        values.put(HORA_PROGRAMA, zarpado.getHora_programa());
        values.put(FECHA_PROGRAMA, zarpado.getFecha_programa());
        values.put(HORA_BAJADA, zarpado.getHora_bajada());
        values.put(LATITUD, zarpado.getLatitud());
        values.put(LONGITUD, zarpado.getLongitud());
        values.put(DETALLE, zarpado.getDetalle());
        values.put(ID_CLIENTE, zarpado.getId_cliente());
        values.put(VALOR, zarpado.getValor());
        values.put(ESTADO, zarpado.getEstado());

        //Get Erase others users
//        db.execSQL("delete from "+ TABLE_ZARPADO);


        // insert row
        long user_response = db.insert(TABLE_ZARPADO, null, values);

        return user_response;
    }

    public long createPasajero(DBpasajero pasajero) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID_PASAJERO, pasajero.getId_pasajero());
        values.put(ID_COMPANY, pasajero.getId_company());
        values.put(URL_FOTO, pasajero.getUrl_foto());
        values.put(TIPO_PASAJERO, pasajero.getTipo_pasajero());
        values.put(NOMBRE, pasajero.getName());
        values.put(DIRECCION, pasajero.getDireccion());

        //Get Erase others users
//        db.execSQL("delete from "+ TABLE_ZARPADO);


        // insert row
        long user_response = db.insert(TABLE_PASAJERO, null, values);

        return user_response;
    }

    //endregion

    //region Read

    public DBmovil readMovil() {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_MOVIL;
        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null)
            c.moveToFirst();

        if(c.getCount() > 0){

            DBmovil movil = new DBmovil(c.getString(c.getColumnIndex(NAME)),
                    c.getString(c.getColumnIndex(ID_MOBILE)),
                    c.getString(c.getColumnIndex(ID_COMPANY)));

            return movil;
        }
        else{
            return null;
        }
    }

    public ArrayList<DBruta_recogida> readRuta_recogida() {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_RUTA_RECOGIDA;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBruta_recogida> list = new ArrayList<DBruta_recogida>();

        if(c != null) {
            if (c.moveToFirst()) {
                do {
                    DBruta_recogida ruta_recogida = new DBruta_recogida(c.getString(c.getColumnIndex(ID)),
                            c.getString(c.getColumnIndex(NOMBRE_RECOGIDA)),
                            c.getString(c.getColumnIndex(ID_MOBILE)),
                            c.getString(c.getColumnIndex(ID_CLIENTE)),
                            c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                            c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                            c.getString(c.getColumnIndex(HORA_REALIZA)),
                            c.getString(c.getColumnIndex(VALOR)),
                            c.getString(c.getColumnIndex(DETALLE)),
                            c.getString(c.getColumnIndex(ESTADO)),
                            c.getString(c.getColumnIndex(HORA_TERMINA)),
                            c.getString(c.getColumnIndex(ID_EMPRESA)));

                    list.add(ruta_recogida);
                } while (c.moveToNext());
                return list;
            }else{
                return null;
            }
        }else{
            return null;
        }

    }

    public ArrayList<DBrecogida> readRecogidaByRRId(String id_rr){
        Log.e("FLAG1","READRECOGIDARRBYID");
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_RECOGIDA + " WHERE id_ruta_recogida=" + id_rr;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBrecogida> list = new ArrayList<DBrecogida>();

        if (c.moveToFirst()) {
            do {
                DBrecogida recogida = new DBrecogida(c.getString(c.getColumnIndex(ID)),
                        c.getString(c.getColumnIndex(ID_MOBILE)),
                        c.getString(c.getColumnIndex(DIRECCION)),
                        c.getString(c.getColumnIndex(ID_PASAJERO)),
                        c.getString(c.getColumnIndex(NOMBRE)),
                        c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_REALIZA)),
                        c.getString(c.getColumnIndex(ID_RUTA_RECOGIDA)),
                        c.getString(c.getColumnIndex(ID_CLIENTE)),
                        c.getString(c.getColumnIndex(ESTADO)),
                        c.getString(c.getColumnIndex(DETALLE)),
                        c.getString(c.getColumnIndex(LATITUD)),
                        c.getString(c.getColumnIndex(LONGITUD)),
                        c.getString(c.getColumnIndex(ID_CANCEL)),
                        c.getString(c.getColumnIndex(TELEFONO)),
                        c.getString(c.getColumnIndex(DIRECCION2)),
                        c.getString(c.getColumnIndex(VALOR)));

                list.add(recogida);
            } while (c.moveToNext());
            return list;
        }else{
            return null;
        }

    }

    public ArrayList<DBrecogida> readRecogida() {
        Log.e("FLAG2","READRECOGIDA");
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_RECOGIDA;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBrecogida> list = new ArrayList<DBrecogida>();

        if (c.moveToFirst()) {
            do {
                DBrecogida recogida = new DBrecogida(c.getString(c.getColumnIndex(ID)),
                        c.getString(c.getColumnIndex(ID_MOBILE)),
                        c.getString(c.getColumnIndex(DIRECCION)),
                        c.getString(c.getColumnIndex(ID_PASAJERO)),
                        c.getString(c.getColumnIndex(NOMBRE)),
                        c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_REALIZA)),
                        c.getString(c.getColumnIndex(ID_RUTA_RECOGIDA)),
                        c.getString(c.getColumnIndex(ID_CLIENTE)),
                        c.getString(c.getColumnIndex(ESTADO)),
                        c.getString(c.getColumnIndex(DETALLE)),
                        c.getString(c.getColumnIndex(LATITUD)),
                        c.getString(c.getColumnIndex(LONGITUD)),
                        c.getString(c.getColumnIndex(ID_CANCEL)),
                        c.getString(c.getColumnIndex(TELEFONO)),
                        c.getString(c.getColumnIndex(DIRECCION2)),
                        c.getString(c.getColumnIndex(VALOR)));
                list.add(recogida);
            } while (c.moveToNext());
            return list;
        }else{
            return null;
        }
    }

    public ArrayList<DBruta_zarpe> readRuta_zarpe() {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_RUTA_ZARPE;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBruta_zarpe> list = new ArrayList<DBruta_zarpe>();

        if (c.moveToFirst()) {
            do {
                DBruta_zarpe ruta_zarpe = new DBruta_zarpe(c.getString(c.getColumnIndex(ID)),
                        c.getString(c.getColumnIndex(DIRECCION)),
                        c.getString(c.getColumnIndex(ID_MOBILE)),
                        c.getString(c.getColumnIndex(ID_CLIENTE)),
                        c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_REALIZA)),
                        c.getString(c.getColumnIndex(VALOR)),
                        c.getString(c.getColumnIndex(DETALLE)),
                        c.getString(c.getColumnIndex(ESTADO)),
                        c.getString(c.getColumnIndex(ID_EMPRESA)));
                list.add(ruta_zarpe);
            } while (c.moveToNext());
            return list;
        }else{
            return null;
        }
    }

    public ArrayList<DBzarpado> readZarpado() {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_ZARPADO;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBzarpado> list = new ArrayList<DBzarpado>();

        if (c.moveToFirst()) {
            do {
            DBzarpado zarpado = new DBzarpado(c.getString(c.getColumnIndex(ID)),
                    c.getString(c.getColumnIndex(ID_RUTA_ZARPE)),
                    c.getString(c.getColumnIndex(ID_PASAJERO)),
                    c.getString(c.getColumnIndex(HORA_REALIZA)),
                    c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                    c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                    c.getString(c.getColumnIndex(HORA_BAJADA)),
                    c.getString(c.getColumnIndex(LATITUD)),
                    c.getString(c.getColumnIndex(LONGITUD)),
                    c.getString(c.getColumnIndex(DETALLE)),
                    c.getString(c.getColumnIndex(ID_CLIENTE)),
                    c.getString(c.getColumnIndex(VALOR)),
                    c.getString(c.getColumnIndex(ESTADO)));
                list.add(zarpado);
            } while (c.moveToNext());
            return list;
        }else{
            return null;
        }
    }

    public ArrayList<DBzarpado> readZarpeByRRId(String id_rz){

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_ZARPADO + " WHERE id_ruta_zarpe=" + id_rz;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBzarpado> list = new ArrayList<DBzarpado>();

        if (c.moveToFirst()) {
            do {
                DBzarpado zarpado = new DBzarpado(c.getString(c.getColumnIndex(ID)),
                        c.getString(c.getColumnIndex(ID_RUTA_ZARPE)),
                        c.getString(c.getColumnIndex(ID_PASAJERO)),
                        c.getString(c.getColumnIndex(HORA_REALIZA)),
                        c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                        c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_BAJADA)),
                        c.getString(c.getColumnIndex(LATITUD)),
                        c.getString(c.getColumnIndex(LONGITUD)),
                        c.getString(c.getColumnIndex(DETALLE)),
                        c.getString(c.getColumnIndex(ID_CLIENTE)),
                        c.getString(c.getColumnIndex(ESTADO)),
                        c.getString(c.getColumnIndex(VALOR)));

                list.add(zarpado);
            } while (c.moveToNext());
            return list;
        }else{
            return null;
        }
    }

    public ArrayList<DBpasajero> readPasajero() {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_PASAJERO;
        Cursor c = db.rawQuery(selectQuery, null);
        ArrayList<DBpasajero> list = new ArrayList<>();

        if (c.moveToFirst()) {
            do {
            DBpasajero pasajero = new DBpasajero(c.getString(
                    c.getColumnIndex(ID_PASAJERO)),
                    c.getString(c.getColumnIndex(ID_COMPANY)),
                    c.getString(c.getColumnIndex(URL_FOTO)),
                    c.getString(c.getColumnIndex(TIPO_PASAJERO)),
                    c.getString(c.getColumnIndex(NOMBRE)),
                    c.getString(c.getColumnIndex(DIRECCION)));
                list.add(pasajero);
            } while (c.moveToNext());
            return list;
        }else{
            return null;
        }
    }

    //endregion

    //region Update

    public void updateMovil(DBmovil movil){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME, movil.getName());
        values.put(ID_MOBILE, movil.getId_mobile());
        values.put(ID_COMPANY, movil.getId_company());

        db.update("sodexo", values, "id="+movil.getId_mobile(),null);
    }

    public void updateRuta_recogida(DBruta_recogida ruta_recogida){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, ruta_recogida.getId());
        values.put(NOMBRE_RECOGIDA, ruta_recogida.getNombre_recogida());
        values.put(ID_MOBILE, ruta_recogida.getId_mobile());
        values.put(ID_CLIENTE, ruta_recogida.getId_cliente());
        values.put(FECHA_PROGRAMA, ruta_recogida.getFecha_programa());
        values.put(HORA_PROGRAMA, ruta_recogida.getHora_programa());
        values.put(HORA_REALIZA, ruta_recogida.getHora_realiza());
        values.put(VALOR, ruta_recogida.getValor());
        values.put(DETALLE, ruta_recogida.getDetalle());
        values.put(ESTADO, ruta_recogida.getEstado());
        values.put(HORA_TERMINA, ruta_recogida.getHora_termina());
        values.put(ID_EMPRESA, ruta_recogida.getId_empresa());

        db.update("sodexo", values, "id="+ruta_recogida.getId(),null);
    }

    public void updateRecogida(DBrecogida recogida){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, recogida.getId());
        values.put(DIRECCION, recogida.getDireccion());
        values.put(ID_PASAJERO, recogida.getId_pasajero());
        values.put(FECHA_PROGRAMA, recogida.getFecha_programa());
        values.put(HORA_PROGRAMA, recogida.getHora_programa());
        values.put(HORA_REALIZA, recogida.getHora_realiza());
        values.put(ID_RUTA_RECOGIDA, recogida.getId_ruta_recogida());
        values.put(ID_CLIENTE, recogida.getId_cliente());
        values.put(ESTADO, recogida.getEstado());
        values.put(DETALLE, recogida.getDetalle());
        values.put(LATITUD, recogida.getLatitud());
        values.put(LONGITUD, recogida.getLongitud());
        values.put(VALOR, recogida.getValor());
        values.put(ID_CANCEL, recogida.getId_cancel());

        db.update("sodexo", values, "id="+recogida.getId(),null);
    }

    public void updateRuta_zarpe(DBruta_zarpe ruta_zarpe){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, ruta_zarpe.getId());
        values.put(DIRECCION, ruta_zarpe.getDireccion());
        values.put(ID_MOBILE, ruta_zarpe.getId_mobile());
        values.put(ID_CLIENTE, ruta_zarpe.getId_cliente());
        values.put(FECHA_PROGRAMA, ruta_zarpe.getFecha_programa());
        values.put(HORA_PROGRAMA, ruta_zarpe.getHora_programa());
        values.put(HORA_REALIZA, ruta_zarpe.getHora_realiza());
        values.put(VALOR, ruta_zarpe.getValor());
        values.put(DETALLE, ruta_zarpe.getDetalle());
        values.put(ESTADO, ruta_zarpe.getEstado());
        values.put(ID_EMPRESA, ruta_zarpe.getId_empresa());

        db.update("sodexo", values, "id="+ruta_zarpe.getId(),null);
    }

    public void updateZarpado(DBzarpado zarpado){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID, zarpado.getId());
        values.put(ID_RUTA_ZARPE, zarpado.getId_ruta_zarpe());
        values.put(ID_PASAJERO, zarpado.getId_pasajero());
        values.put(HORA_REALIZA, zarpado.getHora_realiza());
        values.put(HORA_PROGRAMA, zarpado.getHora_programa());
        values.put(FECHA_PROGRAMA, zarpado.getFecha_programa());
        values.put(HORA_BAJADA, zarpado.getHora_bajada());
        values.put(LATITUD, zarpado.getLatitud());
        values.put(LONGITUD, zarpado.getLongitud());
        values.put(DETALLE, zarpado.getDetalle());
        values.put(ID_CLIENTE, zarpado.getId_cliente());
        values.put(VALOR, zarpado.getValor());
        values.put(ESTADO, zarpado.getEstado());

        db.update("sodexo", values, "id="+zarpado.getId(),null);
    }

    //endregion

    //region delete

    public void deleteMovil(String id){
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("delete from " + TABLE_MOVIL + " where id_mobile=" + id);
    }

    public void deleteRuta_recogida(String id){
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("delete from " + TABLE_RUTA_RECOGIDA + " where id=" + id);
    }

    public void deleteRecogida(String id){
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("delete from " + TABLE_RECOGIDA + " where id=" + id);
    }

    public void deleteRuta_zarpe(String id){
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("delete from " + TABLE_RUTA_ZARPE + " where id=" + id);
    }

    public void deleteZarpado(String id){
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("delete from " + TABLE_ZARPADO + " where id=" + id);
    }

    //endregion

    //region FUNCIONES

    private boolean isNull(Object obj) {
        return obj == null;
    }

    public String buscarRut(String rut) throws JSONException{

        ArrayList<DBpasajero> listPax = new ArrayList<>();
        listPax = readPasajero();
        JSONObject result = new JSONObject();
        int flag = 0;

        for (int i = 0; i < listPax.size() ; i++){
            if(listPax.get(i).getId_pasajero().equals(rut)){
                result.put("success", true);
                result.put("estado", 2);
                return String.valueOf(result);
            }
            else{
                result.put("success", true);
                result.put("estado", 3);
            }
        }
        result.put("success", false);
        return String.valueOf(result);
    }

    public String getRutasRecogida(String id_chofer) throws JSONException {
        Log.e("Get Ruta Recogida", "getRutaRecogida");
        ArrayList<DBruta_recogida> list;
        list = readRuta_recogida();

        JSONObject jsonData = new JSONObject();
        JSONArray jsonArray = new JSONArray();

        if(isNull(list)){
            jsonData.put("status", "false");
            return String.valueOf(jsonData);
        }

        if(!isNull(list)){
            for(int i=0; i<list.size(); i++) {
                if(list.get(i).getEstado().equals("4")){
                    JSONObject jsonObjectData = new JSONObject();
                    jsonObjectData.put("id", list.get(i).getId());
                    jsonObjectData.put("nombre", list.get(i).getNombre_recogida());
                    jsonObjectData.put("fecha", list.get(i).getFecha_programa());
                    jsonObjectData.put("hora", list.get(i).getHora_programa());
                    jsonObjectData.put("hora_termina", list.get(i).getHora_termina());

                    jsonArray.put(jsonObjectData);
                }

            }
        }
        else{
            Log.e("no hay rutas", "no hay rutas");
        }

        if(list.size() > 0){
            jsonData.put("status", true);
            jsonData.put("data", jsonArray);
        }
        else {
            jsonData.put("status", "false");
        }

        //Data", String.valueOf(jsonData));
        return String.valueOf(jsonData);
    }

    public String addPaxRecogida(String rut, String id_ruta_recogida, String foto, String latitud, String longitud) throws JSONException {

        JSONObject data = new JSONObject();
        ArrayList<DBrecogida> dBrecogidas = readRecogidaByRRId(id_ruta_recogida);
        ArrayList<DBpasajero> dBpasajeros = readPasajero();
        ArrayList<DBrecogida> Alldbrecogidas = readRecogida();
        Boolean exists = false;
        int majorId = 0;
        DBpasajero dBpasajero = null;

        DBmovil dBmovil = readMovil();

        String id_cliente = dBmovil.getId_company();

        if(!isNull(dBrecogidas)){
            for (int i = 0; i < dBrecogidas.size(); i++){
                if(dBrecogidas.get(i).getId_pasajero().equals(rut)){
                    //Return Data
                    data = new JSONObject();
                    data.put("success",false);
                    return String.valueOf(data);
                }
            }
        }

        if(!isNull(Alldbrecogidas)){
            for (int i = 0; i < Alldbrecogidas.size(); i++) {
                if( majorId < Integer.parseInt(Alldbrecogidas.get(i).getId()) ){
                    majorId = Integer.parseInt(Alldbrecogidas.get(i).getId());
                }
            }
        }

        majorId = majorId + 1;

        for (int i = 0; i < dBpasajeros.size(); i++){
            if( dBpasajeros.get(i).getId_pasajero().equals(rut)) {
                exists = true;
                dBpasajero = new DBpasajero(
                        dBpasajeros.get(i).getId_pasajero(),
                        dBpasajeros.get(i).getId_company(),
                        dBpasajeros.get(i).getUrl_foto(),
                        dBpasajeros.get(i).getTipo_pasajero(),
                        dBpasajeros.get(i).getName(),
                        dBpasajeros.get(i).getDireccion()
                );
            }
        }

        // Create an instance of SimpleDateFormat used for formatting
        // the string representation of date (month/day/year)
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        df.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));
        DateFormat dt = new SimpleDateFormat("HH:mm:ss");
        dt.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));

        // Get the date today using Calendar object.
        Date today = Calendar.getInstance().getTime();
        Date todayTime = Calendar.getInstance().getTime();

        // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String reportDate = df.format(today);
        String reportTime = dt.format(todayTime);

        if (!exists){
            dBpasajero = new DBpasajero(
                    rut,
                    id_cliente,
                    foto,
                    "2",
                    "",
                    ""

            );
            createPasajero(dBpasajero);

        }

        DBrecogida new_dBrecogida = new DBrecogida(
                String.valueOf(majorId),
                "",
                "",
                rut,
                "",
                reportDate,
                reportTime,
                "",
                id_ruta_recogida,
                id_cliente,
                "4",
                latitud,
                longitud,
                "",
                "",
                "",
                "",
                "-1"
        );

        createRecogida(new_dBrecogida);

        //Return Data
        data = new JSONObject();
        data.put("success",true);
        data.put("id",new_dBrecogida.getId());
        data.put("rut",dBpasajero.getId_pasajero());
        data.put("nombre",dBpasajero.getName());
        data.put("fecha", new_dBrecogida.getFecha_programa() );
        data.put("hora", new_dBrecogida.getHora_programa() );
        data.put("direccion",new_dBrecogida.getDireccion());
        data.put("comuna", new_dBrecogida.getDireccion2());
        data.put("telefono", new_dBrecogida.getTelefono());

        return String.valueOf(data);
    }

    public String addPaxZarpe(String rut, String id_ruta_zarpe, String foto) throws JSONException {

        JSONObject data = new JSONObject();
        ArrayList<DBzarpado> AlldBzarpados = readZarpado();
        ArrayList<DBzarpado> dBzarpados = readZarpeByRRId(id_ruta_zarpe);
        ArrayList<DBpasajero> dBpasajeros = readPasajero();

        Boolean exists = false;
        Boolean fromZarpe = false;
        int passengerLocation = 0;
        int majorId = 0;
        DBpasajero dBpasajero = null;

        DBmovil dBmovil = readMovil();

        String id_cliente = dBmovil.getId_company();


        //Para obtener id maximo
        if(!isNull(AlldBzarpados)){
            for (int i = 0; i < AlldBzarpados.size(); i++){
                if( majorId < Integer.parseInt(AlldBzarpados.get(i).getId()) ){
                    majorId = Integer.parseInt(AlldBzarpados.get(i).getId());
                }
            }
        }

        majorId = majorId + 1;

        //Luego vemos si existe el pasajero
        for (int i = 0; i < dBpasajeros.size(); i++){
            if( dBpasajeros.get(i).getId_pasajero().equals(rut)) {
                exists = true;
                passengerLocation = i;
            }
        }

        //Luego comparamos si es que es del zarpe
        if(!isNull(dBzarpados)) {
            for (int i = 0; i < dBzarpados.size(); i++) {
                if (dBzarpados.get(i).getId_pasajero().equals(rut)) {
                    fromZarpe = true;
                }
            }
        }


        // Create an instance of SimpleDateFormat used for formatting
        // the string representation of date (month/day/year)
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        df.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));
        DateFormat dt = new SimpleDateFormat("HH:mm:ss");
        dt.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));

        // Get the date today using Calendar object.
        Date today = Calendar.getInstance().getTime();
        Date todayTime = Calendar.getInstance().getTime();

        // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String reportDate = df.format(today);
        String reportTime = dt.format(todayTime);

        if(exists){
            if(fromZarpe){
                //Es el caso cuando es del zarpe
                dBpasajero = dBpasajeros.get(passengerLocation);
            }else{
                //Cuando no es del zarpe
                dBpasajero = dBpasajeros.get(passengerLocation);
                DBzarpado new_dBzarpado = new DBzarpado(
                        String.valueOf(majorId),
                        id_ruta_zarpe,
                        rut,
                        "",
                        reportTime,
                        reportDate,
                        "",
                        "",
                        "",
                        "",
                        id_cliente,
                        "4",
                        "-1"
                );

                createZarpado(new_dBzarpado);
            }

        }

        if (!exists){
            dBpasajero = new DBpasajero(
                    rut,
                    id_cliente,
                    foto,
                    "2",
                    "",
                    ""
            );
            createPasajero(dBpasajero);
            DBzarpado new_dBzarpado = new DBzarpado(
                    String.valueOf(majorId),
                    id_ruta_zarpe,
                    rut,
                    "",
                    reportTime,
                    reportDate,
                    "",
                    "",
                    "",
                    "",
                    id_cliente,
                    "4",
                    "-1"
            );

            createZarpado(new_dBzarpado);
        }

        //Return Data
        data = new JSONObject();
        data.put("success",true);

        return String.valueOf(data);
    }

    public String finishRecogida(String estado, String id_recogida, String latitud, String longitud, String detalle) throws JSONException {
        SQLiteDatabase db = this.getWritableDatabase();

        // Create an instance of SimpleDateFormat used for formatting
        // the string representation of date (month/day/year)
        DateFormat dt = new SimpleDateFormat("HH:mm:ss");
        dt.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));

        // Get the date today using Calendar object.
        Date todayTime = Calendar.getInstance().getTime();

        // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String reportTime = dt.format(todayTime);


        if(estado.equals("0")) {
            db.execSQL("update " + TABLE_RECOGIDA + " set estado = " + "5" + ", latitud= " + latitud + ", longitud= " + longitud + ",detalle= '" + detalle + "', hora_realiza= '" + reportTime + "' where id=" + id_recogida);
        }
        else {
            db.execSQL("update " + TABLE_RECOGIDA + " set estado = " + "6" + ", latitud= " + latitud + ", longitud= " + longitud + ",detalle= '" + detalle + "', hora_realiza= '" + reportTime + "' where id=" + id_recogida);
        }
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("success", true);
        Log.e("jsonObjectSalida", String.valueOf(jsonObject));

        return String.valueOf(jsonObject);
    }

    public String finishRecogidaWithPrice(String estado, String id_recogida, String latitud, String longitud, String detalle, String amount) throws JSONException {
        SQLiteDatabase db = this.getWritableDatabase();

        // Create an instance of SimpleDateFormat used for formatting
        // the string representation of date (month/day/year)
        DateFormat dt = new SimpleDateFormat("HH:mm:ss");
        dt.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));

        // Get the date today using Calendar object.
        Date todayTime = Calendar.getInstance().getTime();

        // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String reportTime = dt.format(todayTime);

        if(estado.equals("0")) {
            db.execSQL("update " + TABLE_RECOGIDA + " set estado = " + "5" + ", latitud= " + latitud + ", longitud= " + longitud + ",detalle= '" + detalle + "', hora_realiza= '" + reportTime + "', valor= '" + amount + "' where id=" + id_recogida);
        }
        else {
            db.execSQL("update " + TABLE_RECOGIDA + " set estado = " + "6" + ", latitud= " + latitud + ", longitud= " + longitud + ",detalle= '" + detalle + "', hora_realiza= '" + reportTime + "', valor= '" + amount + "' where id=" + id_recogida);
        }
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("success", true);
        Log.e("jsonObjectSalida", String.valueOf(jsonObject));

        return String.valueOf(jsonObject);
    }

    public DBrecogida getRecogidaPrice(String id_recogida){

        Log.e("FLAG1","READRECOGIDABYID");
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_RECOGIDA + " WHERE id=" + id_recogida;
        Cursor c = db.rawQuery(selectQuery, null);
        DBrecogida node = null;

        if (c.moveToFirst()) {
            do {
                node = new DBrecogida(c.getString(c.getColumnIndex(ID)),
                c.getString(c.getColumnIndex(ID_MOBILE)),
                c.getString(c.getColumnIndex(DIRECCION)),
                c.getString(c.getColumnIndex(ID_PASAJERO)),
                c.getString(c.getColumnIndex(NOMBRE)),
                c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                c.getString(c.getColumnIndex(HORA_REALIZA)),
                c.getString(c.getColumnIndex(ID_RUTA_RECOGIDA)),
                c.getString(c.getColumnIndex(ID_CLIENTE)),
                c.getString(c.getColumnIndex(ESTADO)),
                c.getString(c.getColumnIndex(DETALLE)),
                c.getString(c.getColumnIndex(LATITUD)),
                c.getString(c.getColumnIndex(LONGITUD)),
                c.getString(c.getColumnIndex(ID_CANCEL)),
                c.getString(c.getColumnIndex(TELEFONO)),
                c.getString(c.getColumnIndex(DIRECCION2)),
                c.getString(c.getColumnIndex(VALOR)));
            } while (c.moveToNext());
            return node;
        }else{
            return null;
        }

    }

    public DBzarpado getZarpePrice(String id_zarpe){

        Log.e("FLAG2","READZARPEBYID");
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_ZARPADO + " WHERE id=" + id_zarpe;
        Cursor c = db.rawQuery(selectQuery, null);
        DBzarpado node = null;

        if (c.moveToFirst()) {
            do {
                node = new DBzarpado(c.getString(c.getColumnIndex(ID)),
                        c.getString(c.getColumnIndex(ID_RUTA_ZARPE)),
                        c.getString(c.getColumnIndex(ID_PASAJERO)),
                        c.getString(c.getColumnIndex(HORA_REALIZA)),
                        c.getString(c.getColumnIndex(HORA_PROGRAMA)),
                        c.getString(c.getColumnIndex(FECHA_PROGRAMA)),
                        c.getString(c.getColumnIndex(HORA_BAJADA)),
                        c.getString(c.getColumnIndex(LATITUD)),
                        c.getString(c.getColumnIndex(LONGITUD)),
                        c.getString(c.getColumnIndex(DETALLE)),
                        c.getString(c.getColumnIndex(ID_CLIENTE)),
                        c.getString(c.getColumnIndex(ESTADO)),
                        c.getString(c.getColumnIndex(VALOR)));
            } while (c.moveToNext());
            return node;
        }else{
            return null;
        }

    }

    public int getTotalRecogida( String id_ruta){

        ArrayList<DBrecogida> list = null;
        list = readRecogidaByRRId(id_ruta);
        int value = 0;

        if(list != null){
            for (int i = 0; i < list.size(); i++){
                value = value + Integer.valueOf(list.get(i).getValor());
            }
            return value;
        }else{
            return value;
        }

    }

    class PaxZarpe{
        String rut;
        String latitud;
        String longitud;
        String hora_realiza;
        String tarifa;

        public PaxZarpe(String rut, String latitud, String longitud, String hora_realiza, String tarifa) {
            this.rut = rut;
            this.latitud = latitud;
            this.longitud = longitud;
            this.hora_realiza = hora_realiza;
            this.tarifa = tarifa;
        }

        public String getRut() {
            return rut;
        }

        public void setRut(String rut) {
            this.rut = rut;
        }

        public String getLatitud() {
            return latitud;
        }

        public void setLatitud(String latitud) {
            this.latitud = latitud;
        }

        public String getLongitud() {
            return longitud;
        }

        public void setLongitud(String longitud) {
            this.longitud = longitud;
        }

        public String getHora_realiza() {
            return hora_realiza;
        }

        public void setHora_realiza(String hora_realiza) {
            this.hora_realiza = hora_realiza;
        }

        public String getTarifa() {
            return tarifa;
        }

        public void setTarifa(String tarifa) {
            this.tarifa = tarifa;
        }
    }

    public Boolean buscarInRutsListos(String rut, ArrayList<PaxZarpe> ruts){

        Boolean flag = false;

        for(int i=0; i < ruts.size(); i++) {
            if(rut.equals(ruts.get(i).getRut())){
                flag =true;
            }
        }
        return flag;
    }

    public String obtenerLongitud(String rut, ArrayList<PaxZarpe> ruts){
        for(int i=0; i < ruts.size(); i++) {
            if(rut.equals(ruts.get(i).getRut())){
                return ruts.get(i).getLongitud();
            }
        }
        return "0";
    }

    public String obtenerLatitud(String rut, ArrayList<PaxZarpe> ruts){
        for(int i=0; i < ruts.size(); i++) {
            if(rut.equals(ruts.get(i).getRut())){
                return ruts.get(i).getLatitud();
            }
        }
        return "0";
    }

    public String obtenerHoraBajadaPasajero(String rut, ArrayList<PaxZarpe> ruts){
        for(int i=0; i < ruts.size(); i++) {
            if(rut.equals(ruts.get(i).getRut())){
                return ruts.get(i).getHora_realiza();
            }
        }
        return "0";
    }

    public String obtenerTarifa(String rut, ArrayList<PaxZarpe> ruts){
        for(int i=0; i < ruts.size(); i++) {
            if(rut.equals(ruts.get(i).getRut())){
                return ruts.get(i).getTarifa();
            }
        }
        return "0";
    }

    public String getNameFromRut(String rut){
        ArrayList<DBpasajero> listPax = new ArrayList<>();
        listPax = readPasajero();
        JSONObject result = new JSONObject();
        int flag = 0;

        for (int i = 0; i < listPax.size() ; i++){
            if(listPax.get(i).getId_pasajero().equals(rut)){
                if(listPax.get(i).getName().equals("")){
                    return String.valueOf("Desconocido");
                }else{
                    return listPax.get(i).getName();
                }
            }
        }
        return String.valueOf("Desconocido");
    }

    public String addPrice(String valor, String tipo_operacion, String id, String json_pax, ArrayList<String> rutsListos, String hora_empieza, String hora_inicio_recogida) throws JSONException {

        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        df.setTimeZone(TimeZone.getTimeZone("Chile/Continental"));
        String date = df.format(Calendar.getInstance().getTime());

        SQLiteDatabase db = this.getWritableDatabase();

        if(tipo_operacion.equals("1") ){
            String longitud_pasajero;
            String latitud_pasajeo;
            String hora_bajada_pasajero = "";
            String tarifa = "";

            ArrayList<PaxZarpe> paxZarpes = new ArrayList<PaxZarpe>();
            PaxZarpe paxZarpe;

            JSONArray jsonarray = new JSONArray(json_pax);
            Log.e("jsonsito", String.valueOf(jsonarray));

            for(int m=0; m<jsonarray.length(); m++){
                JSONObject data = jsonarray.getJSONObject(m);
                Log.e("data", String.valueOf(data));

                String rut = data.getString("rut");
                String latitud = data.getString("latitud");
                String longitud = data.getString("longitud");
                String hora_realiza = data.getString("hora_realiza");
                tarifa = data.getString("tarifa");

                paxZarpe = new PaxZarpe(rut, latitud, longitud, hora_realiza,tarifa);
                paxZarpes.add(paxZarpe);
            }

            for(int x = 0; x<paxZarpes.size();x++){
                Log.e("Paxzarpes rut", paxZarpes.get(x).getRut());
                Log.e("Paxzarpes longitud", paxZarpes.get(x).getLongitud());
                Log.e("Paxzarpes latitud", paxZarpes.get(x).getLatitud());
                Log.e("Paxzarpes hora_realiza", paxZarpes.get(x).getHora_realiza());
                Log.e("Paxzarpes tarifa", paxZarpes.get(x).getTarifa());
            }


            // Caso Zarpes
            ArrayList<DBzarpado>  dBzarpados  = readZarpeByRRId(id);
            //Terminar ruta zarpe
            db.execSQL("update " + TABLE_RUTA_ZARPE + " SET valor= '" + valor + "', hora_realiza= '" + date +  "', estado='5' where id=" + id);
            if(!isNull(dBzarpados)){

                for (int i = 0; i < dBzarpados.size(); i ++){

//                    Log.e("id", "id: " + id);
//                    Log.e("id_rutazarpe", "rutazarpe dbzarpados: " + dBzarpados.get(i).getId_ruta_zarpe());

                    if(dBzarpados.get(i).getId_ruta_zarpe().equals(id)){
                        if(buscarInRutsListos(dBzarpados.get(i).getId_pasajero(),paxZarpes)){
                            latitud_pasajeo = obtenerLatitud(dBzarpados.get(i).getId_pasajero(), paxZarpes);
                            longitud_pasajero = obtenerLongitud(dBzarpados.get(i).getId_pasajero(), paxZarpes);
                            hora_bajada_pasajero = obtenerHoraBajadaPasajero(dBzarpados.get(i).getId_pasajero(), paxZarpes);
                            tarifa = obtenerTarifa(dBzarpados.get(i).getId_pasajero(), paxZarpes);
                            String var_detalle = "OK";
                            Log.e("UPDATE ZARPADO","update " + TABLE_ZARPADO + " SET estado = '5'" + ", hora_realiza = '" + hora_empieza + "', hora_bajada = '" + hora_bajada_pasajero +"', latitud =  '" + latitud_pasajeo + "', longitud = '" + longitud_pasajero + "', detalle = '" + var_detalle +"', valor = '" + tarifa +"' where id_pasajero=" + "'" + dBzarpados.get(i).getId_pasajero() + "' AND id= " + dBzarpados.get(i).getId());
                            db.execSQL("update " + TABLE_ZARPADO + " SET estado = '5'" + ", hora_realiza = '" + hora_empieza + "', hora_bajada = '" + hora_bajada_pasajero +"', latitud =  '" + latitud_pasajeo + "', longitud = '" + longitud_pasajero + "', detalle = '" + var_detalle +"', valor = '" + tarifa +"' where id_pasajero=" + "'" + dBzarpados.get(i).getId_pasajero() + "' AND id= " + dBzarpados.get(i).getId());
                        }
                        else{
                            tarifa = obtenerTarifa(dBzarpados.get(i).getId_pasajero(), paxZarpes);
                            String var_detalle = "No Sube";
                            Log.v("UPDATELOG", " update " + TABLE_ZARPADO + " SET estado = '6'" + ", hora_realiza = '" + hora_empieza + "', hora_bajada = '" + hora_bajada_pasajero +"' ,latitud =  '" + " " + "',longitud = '" + " " + "', detalle = '" + var_detalle +"' where id_pasajero='" + dBzarpados.get(i).getId_pasajero() + "' AND id= " + dBzarpados.get(i).getId());
                            db.execSQL(" update " + TABLE_ZARPADO + " SET estado = '6'" + ", hora_realiza = '" + hora_empieza + "', hora_bajada = null ,latitud =  '" + " " + "',longitud = '" + " " + "', detalle = '" + var_detalle +"', valor = '" + tarifa +"' where id_pasajero='" + dBzarpados.get(i).getId_pasajero() + "' AND id='" + dBzarpados.get(i).getId() + "'");
                        }
                    }
                }
            }
        }else{
            //Caso Recogidas
            db.execSQL("update " + TABLE_RUTA_RECOGIDA + " SET valor= '" + valor + "', hora_realiza= '" + hora_inicio_recogida + "', hora_termina= '" + date + "' , estado= '5' where id=" + id);
        }

        JSONObject jsonObjectDato = new JSONObject();
        jsonObjectDato.put("success", true);

        return String.valueOf(jsonObjectDato);
    }

    public String getAddressZarpe(String id_ruta_zarpe, ArrayList<String> rutsListos) throws JSONException {
        Log.e("Get Address Zarpe", "getAddressZarpe");
        ArrayList<DBpasajero> list;
        ArrayList<DBzarpado> zarpadosList;

        list = this.readPasajero();
        zarpadosList = this.readZarpeByRRId(id_ruta_zarpe);

        for(int i = 0; i<zarpadosList.size(); i++){
            Log.e("zarpado estado", "zarpado nº :" + i + " estado: " + zarpadosList.get(i).getEstado());
        }

        String rut;
        String direccion;
        String estado = null;
        String tarifa;
        Boolean flag;
        Boolean usuario_desconocido = false;

        JSONObject jsonData = new JSONObject();
        JSONArray jsonArray = new JSONArray();

        for(int i=0; i<rutsListos.size(); i++) {
            flag = false;
            usuario_desconocido = false;
            for(int j=0; j<list.size(); j++){
                tarifa = "-1";
                if(rutsListos.get(i).equals(list.get(j).getId_pasajero())) {
                    if(list.get(j).getTipo_pasajero().equals(("2"))){
                        estado = "2";
                        usuario_desconocido = true;
                    }
                    rut = rutsListos.get(i);

                    Log.e("rut", rut);

                    JSONObject jsonObjectData = new JSONObject();

                    Log.e("zarpadosList size", "zarpadosList size: " + zarpadosList.size());
                    Log.e("rutsListos size", "rutsListos size: " + rutsListos.size());

                    direccion = list.get(j).getDireccion();

                    for (int k = 0; k < zarpadosList.size(); k++) {
                        if (rut.equals(zarpadosList.get(k).getId_pasajero()) && !usuario_desconocido) {
                            flag = true;
                            tarifa = zarpadosList.get(k).getValor();
                        }

                    }

                    if(flag){
                        estado = "1";
                    }
                    else{
                        estado = "2";
                    }

                    jsonObjectData.put("rut", rut);
                    jsonObjectData.put("direccion", direccion);
                    jsonObjectData.put("tipo_usuario", estado);
                    jsonObjectData.put("tarifa", tarifa);

                    jsonArray.put(jsonObjectData);
                }
            }
        }


        if(list.size() > 0){
            jsonData.put("status", true);
            jsonData.put("data", jsonArray);
        }
        else {
            jsonData.put("status", "false");
        }

        //Log.e("jsonData", String.valueOf(jsonData));
        return String.valueOf(jsonData);
    }

    public String getRutasZarpes(String id_chofer) throws JSONException {
        Log.e("Get Rutas Zarpes", "getRutasZarpes");
        ArrayList<DBruta_zarpe> list;
        list = this.readRuta_zarpe();

        Boolean flag = false;

        JSONObject jsonData = new JSONObject();
        JSONArray jsonArray = new JSONArray();

        if(isNull(list)){
            jsonData.put("status", "false");
            return String.valueOf(jsonData);
        }

        if(!isNull(list)){
            for(int i=0; i<list.size(); i++) {
                if(list.get(i).getEstado().equals("4")){
                    flag = true;
                    JSONObject jsonObjectData = new JSONObject();
                    jsonObjectData.put("id", list.get(i).getId());
                    jsonObjectData.put("movil", list.get(i).getId_mobile());
                    jsonObjectData.put("fecha", list.get(i).getFecha_programa());
                    jsonObjectData.put("hora", list.get(i).getHora_programa());
                    jsonObjectData.put("direccion", list.get(i).getDireccion());

                    jsonArray.put(jsonObjectData);
                }
            }
        }

        if(list.size() > 0 && flag){
            jsonData.put("status", true);
            jsonData.put("data", jsonArray);
        }
        else {
            jsonData.put("status", "false");
        }

        //Log.e("jsonData", String.valueOf(jsonData));
        return String.valueOf(jsonData);
    }

    public String getRecogida(String id_ruta_recogida) throws JSONException {
        Log.e("Get Recogida", "getRecogida");
        ArrayList<DBrecogida> list;

        Boolean flag = false;

        list = this.readRecogida();

        JSONArray jsonArray = new JSONArray();
        JSONObject jsonData = new JSONObject();

        if(!isNull(list)){
            for(int i=0; i<list.size(); i++){
                if(id_ruta_recogida.equals(list.get(i).getId_ruta_recogida())){
                    if(list.get(i).getEstado().equals("4")){
                        flag = true;
                        JSONObject jsonObjectData = new JSONObject();
                        jsonObjectData.put("id", list.get(i).getId());
                        jsonObjectData.put("direccion", list.get(i).getDireccion());
                        jsonObjectData.put("rut_pasajero", list.get(i).getId_pasajero());
                        jsonObjectData.put("nombre_pasajero", list.get(i).getNombre());
                        jsonObjectData.put("fecha", list.get(i).getFecha_programa());
                        jsonObjectData.put("hora", list.get(i).getHora_programa());
                        jsonObjectData.put("id_ruta_recogida", list.get(i).getId_ruta_recogida());
                        jsonObjectData.put("phone", list.get(i).getTelefono());
                        jsonObjectData.put("direccion2", list.get(i).getDireccion2());

                        jsonArray.put(jsonObjectData);

                        Log.e("objectdatagetRecogida", String.valueOf(jsonObjectData));

                    }
                }
            }
        }

        if(list.size() > 0 && flag){
            jsonData.put("status", true);
            jsonData.put("data", jsonArray);
        }
        else {
            jsonData.put("status", "false");
        }

        return String.valueOf(jsonData);
    }

    //endregion

    //Synchronization

    //This will empty the Android Database and will fill it with updated data
    public void pullData(Context applicationContext, Boolean option, Intent nextIntent){

        SQLiteDatabase db = this.getWritableDatabase();
        DBmovil dBmovil;

        //First we truncate all tables
        //Truncate RutaRecogida table
        db.execSQL("delete from " + TABLE_RUTA_RECOGIDA);

        //Truncate RutaZarpe table
        db.execSQL("delete from " + TABLE_RUTA_ZARPE);

        //Truncate Recogida table
        db.execSQL("delete from " + TABLE_RECOGIDA);

        //Truncate Zarpado table
        db.execSQL("delete from " + TABLE_ZARPADO);

        //Truncate Pasajero table
        db.execSQL("delete from " + TABLE_PASAJERO);

        //And get the id_mobile
        dBmovil = readMovil();

        //Now we pull data from server
        PullDataRequest pull = new PullDataRequest(db, applicationContext, dBmovil.getId_mobile(), option, nextIntent);
        pull.execute();
    }

    public class PullDataRequest extends AsyncTask<Void, Void, Void> {
        private static final String SERVER_URL_REQUEST_LOGIN ="http://passenger.dis-patcher.cl/pullData.php" ;
        private final String USER_AGENT = "Mozilla/5.0";
        private final String id_mobile;
        SQLiteDatabase db;
        private String user = "";
        private String password = "";
        private String json_decoded = "";
        private Context context;
        private String status;
        private String id;
        private String id_movil;
        private String mobile;
        private String nombre;
        private String fecha_programa;
        private String hora_programa;
        private String id_cliente;
        private String id_empresa;
        private String id_recogida;
        private String direccion;
        private String rut_pasajero;
        private String nombre_pasajero;
        private String fecha;
        private String id_ruta_recogida;
        private String phone;
        private String comuna;
        private String estado;
        private String nombre_zarpe;
        private String id_ruta_zarpe;
        private String id_zarpe;
        private JSONArray lista_pasajeros;
        private Boolean option;
        private Intent nextIntent;
        private String tarifa;


        public PullDataRequest(SQLiteDatabase db, Context applicationContext, String id_mobile, Boolean option, Intent nextIntent) {
            this.db = db;
            this.context = applicationContext;
            this.id_mobile = id_mobile;
            this.option = option;
            this.nextIntent = nextIntent;
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected Void doInBackground(Void... params) {

            try {
                this.json_decoded = POST(SERVER_URL_REQUEST_LOGIN, "id_mobile=" + this.id_mobile);
            } catch (IOException e) {
                e.printStackTrace();
            }

            String jsonString = this.json_decoded;

            JSONObject allObj = null;

            try {
                allObj = new JSONObject(jsonString);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                status = allObj.getString("success");

                if(status.equals("true")){

                    //We get data objects

                    JSONArray data = null;
                    data = allObj.getJSONArray("data");

                    //We get Rutas
                    for (int i = 0; i < data.length(); i ++){

                        JSONArray rutas = null;
                        if(data.getJSONObject(i).has("ruta_recogida")){
                            rutas = data.getJSONObject(i).getJSONArray("ruta_recogida");

                            for(int j = 0; j < rutas.length() ; j ++){

                                id = rutas.getJSONObject(j).getString("id");
                                nombre = rutas.getJSONObject(j).getString("nombre");
                                mobile = rutas.getJSONObject(j).getString("movil");
                                fecha_programa = rutas.getJSONObject(j).getString("fecha");
                                hora_programa = rutas.getJSONObject(j).getString("hora");
                                id_cliente = rutas.getJSONObject(j).getString("id_cliente");
                                id_empresa = rutas.getJSONObject(j).getString("id_empresa");

                                DBruta_recogida dBruta_recogida = new DBruta_recogida(id,
                                        nombre,
                                        mobile,
                                        id_cliente,
                                        fecha_programa,
                                        hora_programa,
                                        "",
                                        "",
                                        "",
                                        "4",
                                        "",
                                        id_empresa
                                );

                                createRuta_recogida(dBruta_recogida);

                                JSONArray dataRecogida = null;
                                dataRecogida = rutas.getJSONObject(j).getJSONArray("lista_recogidas");

                                for(int k = 0; k < dataRecogida.length() ; k++){

                                    id_recogida = dataRecogida.getJSONObject(k).getString("id");

                                    direccion = dataRecogida.getJSONObject(k).getString("direccion");
                                    rut_pasajero = dataRecogida.getJSONObject(k).getString("rut_pasajero");
                                    nombre_pasajero = dataRecogida.getJSONObject(k).getString("nombre_pasajero");
                                    fecha_programa = dataRecogida.getJSONObject(k).getString("fecha");
                                    hora_programa = dataRecogida.getJSONObject(k).getString("hora");
                                    id_ruta_recogida = dataRecogida.getJSONObject(k).getString("id_ruta_recogida");
                                    phone = dataRecogida.getJSONObject(k).getString("phone");
                                    comuna = dataRecogida.getJSONObject(k).getString("comuna");
                                    tarifa = dataRecogida.getJSONObject(k).getString("tarifa");

                                    DBrecogida dBrecogida = new DBrecogida(id_recogida,
                                            id_mobile,
                                            direccion,
                                            rut_pasajero,
                                            nombre_pasajero,
                                            fecha_programa,
                                            hora_programa,
                                            "",
                                            id_ruta_recogida,
                                            id_cliente,
                                            "4",
                                            "",
                                            "",
                                            "",
                                            "",
                                            phone,
                                            comuna,
                                            tarifa
                                    );
                                    createRecogida(dBrecogida);
                                }
                            }

                        }

                        if(data.getJSONObject(i).has("ruta_zarpe")){
                            rutas = data.getJSONObject(i).getJSONArray("ruta_zarpe");

                            for(int j = 0; j < rutas.length() ; j ++){

                                id = rutas.getJSONObject(j).getString("id");
                                mobile = rutas.getJSONObject(j).getString("movil");
                                fecha_programa = rutas.getJSONObject(j).getString("fecha");
                                hora_programa = rutas.getJSONObject(j).getString("hora");
                                direccion = rutas.getJSONObject(j).getString("direccion");
                                id_cliente = rutas.getJSONObject(j).getString("id_cliente");
                                estado = rutas.getJSONObject(j).getString("estado");
                                id_empresa = rutas.getJSONObject(j).getString("id_empresa");
                                nombre_zarpe = rutas.getJSONObject(j).getString("nombre_zarpe");

                                DBruta_zarpe dBruta_zarpe = new DBruta_zarpe(id,
                                        direccion,
                                        mobile,
                                        id_cliente,
                                        fecha_programa,
                                        hora_programa,
                                        "",
                                        "",
                                        "",
                                        "4",
                                        id_empresa
                                );
                                createRuta_zarpe(dBruta_zarpe);

                                JSONArray dataZarpe = null;
                                dataZarpe = rutas.getJSONObject(j).getJSONArray("lista_zarpes");

                                for(int k = 0; k < dataZarpe.length() ; k++){
                                    id_zarpe = dataZarpe.getJSONObject(k).getString("id");
                                    rut_pasajero = dataZarpe.getJSONObject(k).getString("id_pasajero");
                                    fecha_programa = dataZarpe.getJSONObject(k).getString("fecha_programa");
                                    hora_programa = dataZarpe.getJSONObject(k).getString("hora_programa");
                                    id_ruta_zarpe = dataZarpe.getJSONObject(k).getString("id_ruta_zarpe");
                                    id_cliente = dataZarpe.getJSONObject(k).getString("id_cliente");
                                    estado = dataZarpe.getJSONObject(k).getString("estado");
                                    tarifa = dataZarpe.getJSONObject(k).getString("tarifa");

                                    DBzarpado dBzarpado = new DBzarpado(
                                            id_zarpe,
                                            id_ruta_zarpe,
                                            rut_pasajero,
                                            "",
                                            hora_programa,
                                            fecha_programa,
                                            "",
                                            "",
                                            "",
                                            "",
                                            id_cliente,
                                            estado,
                                            tarifa
                                    );
                                    createZarpado(dBzarpado);
                                }
                            }
                        }
                        if(data.getJSONObject(i).has("pasajeros")){

                            lista_pasajeros = data.getJSONObject(i).getJSONArray("pasajeros");
                            for(int j = 0; j < lista_pasajeros.length() ; j ++) {
                                DBpasajero dBpasajero = new DBpasajero(
                                        lista_pasajeros.getJSONObject(j).getString("id"),
                                        lista_pasajeros.getJSONObject(j).getString("id_company"),
                                        lista_pasajeros.getJSONObject(j).getString("url_foto"),
                                        lista_pasajeros.getJSONObject(j).getString("tipo_pasajero"),
                                        lista_pasajeros.getJSONObject(j).getString("nombre_pasajero"),
                                        lista_pasajeros.getJSONObject(j).getString("direccion")
                                );
                                createPasajero(dBpasajero);
                            }
                        }

                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        private String POST(String url, String urlParameters) throws IOException {
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            //add reuqest header
            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

            //String urlParameters = "sn=C02G8416DRJM&cn=&locale=&caller=&num=12345";

            // Send post request
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result
            return (response.toString());
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            progressDialogWithContext.dismiss();
            if(this.option){
                ((Activity) this.context).finish();
                //((LoginActivity) this.context).finish();
                this.context.startActivity(nextIntent);
            }
        }
    }

    //This will send all the data to Server, and nothing more
    public void pushData(Context applicationContext , Boolean option , Intent nextIntent) throws JSONException {

        /***
         * This function do all the syncro with pullData that is inside of this same function
         * Parameters explanation:
         * applicationContext: (Posible Activity context or null)
         * -> This is the context of the actual activity of the app
         * option: (Posible true or false)
         * ->This defines if you want to go to the next activity after all the process finish, avoiding problems
         * with the Android's UI, if you put false you have to put null in nextIntent and nothing will happen after
         * pushData()  finish
         * nextIntent: (Posible Activity context or null)
         * The referenced intent to go after all the process finish
         */

        //Comienzo de carga
        progressDialogWithContext = new ProgressDialog(applicationContext);
        progressDialogWithContext.setMax(1000);
        progressDialogWithContext.setMessage("Sincronizando datos...");
        progressDialogWithContext.show();


        SQLiteDatabase db = this.getWritableDatabase();
        String id_mobile;
        String id_company;
        String json = "";
        JSONArray total = new JSONArray();
        JSONObject jsonRecogida = new JSONObject();
        JSONObject jsonZarpe = new JSONObject();
        JSONObject jsonPax = new JSONObject();
        ArrayList<DBruta_recogida> rr_list;
        ArrayList<DBrecogida> r_list;
        ArrayList<DBruta_zarpe> rz_list;
        ArrayList<DBzarpado> z_list;
        ArrayList<DBpasajero> p_list;

        //get Id Mobile
        DBmovil dBmovil= readMovil();

        //Here we build the json

        //Primero obtenemos la recogidas
        rr_list = readRuta_recogida();
        if(rr_list != null){
            JSONArray rutas_recogidas = new JSONArray();
            for (int i = 0; i < rr_list.size() ; i ++){
                JSONArray recogidas = new JSONArray();
                r_list = readRecogidaByRRId(rr_list.get(i).getId());
                if(r_list != null){
                    for (int j = 0; j < r_list.size() ; j ++){
                        JSONObject recogida = new JSONObject();
                        recogida.put("id", r_list.get(j).getId());
                        recogida.put("direccion", r_list.get(j).getDireccion());
                        recogida.put("id_pasajero", r_list.get(j).getId_pasajero());
                        recogida.put("fecha_programa", r_list.get(j).getFecha_programa());
                        recogida.put("hora_programa", r_list.get(j).getHora_programa());
                        recogida.put("hora_realiza", r_list.get(j).getHora_realiza());
                        recogida.put("id_rubro_recogida", r_list.get(j).getId_ruta_recogida());
                        recogida.put("id_cliente", r_list.get(j).getId_cliente());
                        recogida.put("estado", r_list.get(j).getEstado());
                        recogida.put("detalle", r_list.get(j).getDetalle());
                        recogida.put("latitud", r_list.get(j).getLatitud());
                        recogida.put("longitud", r_list.get(j).getLongitud());
                        recogida.put("id_cancel", r_list.get(j).getId_cancel());
                        recogida.put("tarifa", r_list.get(j).getValor());
                        recogidas.put(recogida);
                    }
                }
                JSONObject ruta_recogida = new JSONObject();
                ruta_recogida.put("id", rr_list.get(i).getId());
                ruta_recogida.put("id_mobile", rr_list.get(i).getId_mobile());
                ruta_recogida.put("id_cliente", rr_list.get(i).getId_cliente());
                ruta_recogida.put("fecha_programa", rr_list.get(i).getFecha_programa());
                ruta_recogida.put("hora_programa", rr_list.get(i).getHora_programa());
                ruta_recogida.put("hora_realiza", rr_list.get(i).getHora_realiza());
                ruta_recogida.put("valor", rr_list.get(i).getValor());
                ruta_recogida.put("detalle", rr_list.get(i).getDetalle());
                ruta_recogida.put("estado", rr_list.get(i).getEstado());
                ruta_recogida.put("hora_termina", rr_list.get(i).getHora_termina());
                ruta_recogida.put("nombre_recogida", rr_list.get(i).getNombre_recogida());
                ruta_recogida.put("lista_recogidas", recogidas);

                rutas_recogidas.put(ruta_recogida);
            }
            jsonRecogida.put("ruta_recogida", rutas_recogidas);
        }

        //Segundo obtenemos la zarpados
        rz_list = readRuta_zarpe();
        if(rz_list != null){
            JSONArray rutas_zarpes = new JSONArray();
            for (int i = 0; i < rz_list.size() ; i ++){
                JSONArray zarpes = new JSONArray();
                z_list = readZarpeByRRId(rz_list.get(i).getId());
                if(z_list != null){
                    for (int j = 0; j < z_list.size() ; j ++){
                        JSONObject zarpe = new JSONObject();
                        zarpe.put("id", z_list.get(j).getId());
                        zarpe.put("detalle", z_list.get(j).getDetalle());
                        zarpe.put("estado", z_list.get(j).getEstado());
                        zarpe.put("fecha_programa", z_list.get(j).getFecha_programa());
                        zarpe.put("hora_bajada", z_list.get(j).getHora_bajada());
                        zarpe.put("hora_realiza", z_list.get(j).getHora_realiza());
                        zarpe.put("id_cliente", z_list.get(j).getId_cliente());
                        zarpe.put("id_pasajero", z_list.get(j).getId_pasajero());
                        zarpe.put("id_ruta_zarpe", z_list.get(j).getId_ruta_zarpe());
                        zarpe.put("latitud", z_list.get(j).getLatitud());
                        zarpe.put("longitud", z_list.get(j).getLongitud());
                        zarpe.put("hora_programa", z_list.get(j).getHora_programa());
                        zarpe.put("tarifa", z_list.get(j).getValor());
                        zarpes.put(zarpe);
                    }
                }
                JSONObject ruta_zarpe = new JSONObject();
                ruta_zarpe.put("id", rz_list.get(i).getId());
                ruta_zarpe.put("id_mobile", rz_list.get(i).getId_mobile());
                ruta_zarpe.put("id_cliente", rz_list.get(i).getId_cliente());
                ruta_zarpe.put("fecha_programa", rz_list.get(i).getFecha_programa());
                ruta_zarpe.put("hora_programa", rz_list.get(i).getHora_programa());
                ruta_zarpe.put("hora_realiza", rz_list.get(i).getHora_realiza());
                ruta_zarpe.put("valor", rz_list.get(i).getValor());
                ruta_zarpe.put("detalle", rz_list.get(i).getDetalle());
                ruta_zarpe.put("estado", rz_list.get(i).getEstado());
                ruta_zarpe.put("id_empresa", rz_list.get(i).getId_empresa());
                ruta_zarpe.put("lista_zarpes", zarpes);

                rutas_zarpes.put(ruta_zarpe);
            }
            jsonZarpe.put("ruta_zarpe", rutas_zarpes);

        }

        //Tercero obtenemos los pasajeros
        p_list = readPasajero();
        if(p_list != null){
            JSONArray passengers = new JSONArray();
            for (int i = 0; i < p_list.size() ; i ++){
                JSONObject passenger = new JSONObject();
                passenger.put("id_pasajero", p_list.get(i).getId_pasajero());
                passenger.put("id_company", p_list.get(i).getId_company());
                passenger.put("url_foto", p_list.get(i).getUrl_foto());
                passenger.put("tipo_pasajero", p_list.get(i).getTipo_pasajero());
                passenger.put("nombre_pasajero", p_list.get(i).getName());
                passengers.put(passenger);
            }
            jsonPax.put("pasajeros", passengers);
        }

        total.put(jsonRecogida);
        total.put(jsonZarpe);
        total.put(jsonPax);

        //Respuesta final
        JSONObject jsonObjectContainer = new JSONObject();
        jsonObjectContainer.put("success", true);
        jsonObjectContainer.put("id_mobile", dBmovil.getId_mobile());
        jsonObjectContainer.put("id_company", dBmovil.getId_company());

        jsonObjectContainer.put("data", total);

        //Now we push data to server
        PushDataRequest pull = new PushDataRequest(db, applicationContext, jsonObjectContainer, option, nextIntent);
        pull.execute();

    }

    public class PushDataRequest extends AsyncTask<Void, Void, Void> {
        private static final String SERVER_URL_REQUEST_LOGIN ="http://passenger.dis-patcher.cl/pushData.php" ;
        private final String USER_AGENT = "Mozilla/5.0";
        SQLiteDatabase db;
        private String user = "";
        private String password = "";
        private String json_decoded = "";
        private Context context;
        private String status;
        private String id;
        private String mobile;
        private String nombre;
        private String fecha_programa;
        private String hora_programa;
        private String id_cliente;
        private String id_empresa;
        private String id_recogida;
        private String direccion;
        private String rut_pasajero;
        private String nombre_pasajero;
        private String fecha;
        private String id_ruta_recogida;
        private String phone;
        private String comuna;
        private String estado;
        private String nombre_zarpe;
        private String id_ruta_zarpe;
        private String id_zarpe;
        private JSONObject json;
        private Boolean option;
        private Intent nextIntent;

        public PushDataRequest(SQLiteDatabase db, Context applicationContext, JSONObject jsonObjectContainer, Boolean option, Intent nextIntent) {
            this.db = db;
            this.context = applicationContext;
            this.json = jsonObjectContainer;
            this.option = option;
            this.nextIntent= nextIntent;
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected Void doInBackground(Void... params) {

            try {
                this.json_decoded = POST(SERVER_URL_REQUEST_LOGIN, "data=" + String.valueOf(this.json));
                Log.v("respuestaServer", String.valueOf(json));
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        private String POST(String url, String urlParameters) throws IOException {
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            //add reuqest header
            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

            //String urlParameters = "sn=C02G8416DRJM&cn=&locale=&caller=&num=12345";

            // Send post request
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();

            BufferedReader in = new BufferedReader(
            new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result
            return (response.toString());
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            pullData(this.context , this.option , this.nextIntent );
        }
    }

    //endsynchronization

    //Comienzo progressDialog


    //End Region

}

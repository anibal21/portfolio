package com.example.autumn.kustody.utils;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import com.example.autumn.kustody.R;

import java.util.ArrayList;

/**
 * Created by anibalsci on 15-12-17.
 */

public class AsyntaskHandlerClass {

    private static AsyntaskHandlerClass mInstance= null;

    private ArrayList<LoaderAsynctask> asynctaskList;

    protected AsyntaskHandlerClass(){}

    public static synchronized AsyntaskHandlerClass getInstance(){
        if(null == mInstance){
            mInstance = new AsyntaskHandlerClass();
        }
        return mInstance;
    }

    public ArrayList<LoaderAsynctask> getAsynctaskList() {
        return this.asynctaskList;
    }

    public void setAsynctaskList(ArrayList<LoaderAsynctask> asynctaskList) {
        this.asynctaskList = asynctaskList;
    }

    public void cleanAsynctaskList(){
        this.asynctaskList.clear();
    }

    public LoaderAsynctask getAsynctaskByImageView(ImageView imageView){
        for( LoaderAsynctask loader : asynctaskList){
            if(loader.getImageView() == imageView){
                return loader;
            }
        }
        return null;
    }

    public void replaceOrCreateLoader(ImageView imageView, String path) {
        int flag = 1;
        if(asynctaskList == null){
            asynctaskList = new ArrayList<LoaderAsynctask>();
        }

        if(asynctaskList.size() > 0){
            int count = 0;
            for (LoaderAsynctask loader : asynctaskList) {
                if (loader.getImageView() == imageView) {
                    loader.cancel(true);
                    LoaderAsynctask loaderInstace = new LoaderAsynctask(path, loader.getImageView());
                    loaderInstace.execute();
                    asynctaskList.set(count,loaderInstace);
                    flag = 2;
                    break;
                }
                count++;
            }
        }

        if(flag == 1){
            LoaderAsynctask loaderInstace = new LoaderAsynctask(path,imageView);
            loaderInstace.execute();
            asynctaskList.add(loaderInstace);
        }
    }
}

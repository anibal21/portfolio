package com.example.autumn.kustody.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import com.example.autumn.kustody.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Created by anibalsci on 15-12-17.
 */

public class LoaderAsynctask extends AsyncTask<Void, Void, Void>{

    private final String path;
    private ImageView imageview;
    private Bitmap bitmap;

    public LoaderAsynctask(String path, ImageView imageview) {
        this.path = path;
        this.imageview = imageview;
    }

    public ImageView getImageView(){
        return this.imageview;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        this.imageview.setImageResource(R.drawable.icon_img);
    }

    @Override
    protected Void doInBackground(Void... voids) {
        this.bitmap = BitmapFactory.decodeFile(path);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        //this.imageview.setImageBitmap(bitmap);
        resize(bitmap,this.imageview,200,200);
        this.bitmap.recycle();
        this.bitmap = null;
        //this.imageview.setImageBitmap(Bitmap.createScaledBitmap(bitmap, 140, 180, false));

    }

    private static Bitmap resize(Bitmap image, ImageView imageView, int maxWidth, int maxHeight) {
        if (maxHeight > 0 && maxWidth > 0) {
            int width = image.getWidth();
            int height = image.getHeight();
            float ratioBitmap = (float) width / (float) height;
            float ratioMax = (float) maxWidth / (float) maxHeight;

            int finalWidth = maxWidth;
            int finalHeight = maxHeight;
            if (ratioMax > ratioBitmap) {
                finalWidth = (int) ((float)maxHeight * ratioBitmap);
            } else {
                finalHeight = (int) ((float)maxWidth / ratioBitmap);
            }
            imageView.setImageBitmap(Bitmap.createScaledBitmap(image, finalWidth, finalHeight, true));
            return image;
        } else {
            return image;
        }
    }

}
package com.example.autumn.kustody.db.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.example.autumn.kustody.R;
import com.example.autumn.kustody.api.service.UserClient;
import com.example.autumn.kustody.db.model.ActivityDB;
import com.example.autumn.kustody.db.model.FileDB;
import com.example.autumn.kustody.db.model.UserDB;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DBHelper extends SQLiteOpenHelper {

    // Logcat tag
    private static final String LOG = "DatabaseHelperKustody";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "kustody";

    // Table Names
    private static final String TABLE_USER = "user";
    private static final String TABLE_ACTIVITY = "activity";
    private static final String TABLE_FILE = "file";

    // Common column names
    private static final String KEY_STATUS = "status";
    private static final String KEY_DETAIL = "detail";
    private static final String KEY_ID = "id";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_BYTES = "bytes";

    // USER Table - column names
    private static final String KEY_PASS = "pass";
    private static final String KEY_TOKEN = "token";
    private static final String KEY_NAME = "name";
    private static final String KEY_LASTNAME = "lastname";
    private static final String KEY_PLAN_ID = "plan_id";
    private static final String KEY_PLAN_NAME = "plan_name";
    private static final String KEY_PLAN_PRICE = "plan_price";
    private static final String KEY_PLAN_STORAGE = "plan_storage";
    private static final String KEY_PLAN_DETAILS = "plan_details";

    private static final String KEY_USER_FILLED_STORAGE = "filled_storage";
    private static final String KEY_USER_FILLED_STORAGE_DOC = "filled_storage_doc";
    private static final String KEY_USER_FILLED_STORAGE_IMAGE = "filled_storage_image";
    private static final String KEY_USER_FILLED_STORAGE_MUSIC = "filled_storage_music";
    private static final String KEY_USER_FILLED_STORAGE_VIDEO = "filled_storage_video";

    //ACTIVITY Table - column names
    private static final String KEY_ACTIONTYPE = "action_type";
    private static final String KEY_INIT_DATE = "init_date";
    private static final String KEY_END_DATE = "end_date";
    private static final String KEY_TOTAL_FILES = "total_files";
    private static final String KEY_CURRENT_FILES = "current_files";

    //FILES Table - column names
    private static final String KEY_ACTIVITYID = "activityid";
    private static final String KEY_FILENAME = "filename";
    private static final String KEY_FILESIZE = "filesize";
    private static final String KEY_FILETYPE = "filetype";
    private static final String KEY_PATH = "path";

    // USER table create statement
    private static final String CREATE_TABLE_USER = "CREATE TABLE " + TABLE_USER
            + "(" + KEY_EMAIL + " TEXT PRIMARY KEY," +
            KEY_PASS + " TEXT," +
            KEY_TOKEN + " TEXT," +
            KEY_STATUS + " TEXT, " +
            KEY_NAME + " TEXT, " +
            KEY_PLAN_ID + " TEXT, " +
            KEY_PLAN_NAME + " TEXT," +
            KEY_LASTNAME + " TEXT," +
            KEY_PLAN_PRICE + " TEXT, " +
            KEY_PLAN_STORAGE + " TEXT, " +
            KEY_PLAN_DETAILS + " TEXT," +
            KEY_USER_FILLED_STORAGE + " TEXT," +
            KEY_USER_FILLED_STORAGE_DOC + " TEXT," +
            KEY_USER_FILLED_STORAGE_IMAGE + " TEXT," +
            KEY_USER_FILLED_STORAGE_MUSIC + " TEXT," +
            KEY_USER_FILLED_STORAGE_VIDEO + " TEXT)";

    // ACTIVITY table create statement
    private static final String CREATE_TABLE_ACTIVITY = "CREATE TABLE " + TABLE_ACTIVITY
            + "(" + KEY_ID + " TEXT PRIMARY KEY," +
            KEY_ACTIONTYPE + " TEXT," +
            KEY_EMAIL + " TEXT," +
            KEY_INIT_DATE + " TEXT," +
            KEY_END_DATE + " TEXT, " +
            KEY_TOTAL_FILES + " TEXT, " +
            KEY_CURRENT_FILES + " TEXT, " +
            KEY_DETAIL + " TEXT, " +
            KEY_BYTES + " TEXT, " +
            KEY_STATUS + " TEXT)";

    // FILES table create statement
    private static final String CREATE_TABLE_FILE = "CREATE TABLE " + TABLE_FILE
            + "(" + KEY_ID + " TEXT PRIMARY KEY," +
            KEY_ACTIVITYID + " TEXT," +
            KEY_EMAIL + " TEXT," +
            KEY_FILENAME + " TEXT, " +
            KEY_FILESIZE + " TEXT, " +
            KEY_FILETYPE + " TEXT, " +
            KEY_STATUS + " TEXT," +
            KEY_DETAIL + " TEXT," +
            KEY_BYTES + " TEXT, " +
            KEY_PATH + " TEXT)";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // creating required tables
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_ACTIVITY);
        db.execSQL(CREATE_TABLE_FILE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // on upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACTIVITY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FILE);

        // create new tables
        onCreate(db);
    }

    /*
     * Creating a UserData
     */
    public Boolean addUser(UserDB user) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_EMAIL, user.getEmail());
        values.put(KEY_PASS, user.getPass());
        values.put(KEY_TOKEN, user.getToken());
        values.put(KEY_STATUS, user.getStatus());
        values.put(KEY_NAME, user.getName());
        values.put(KEY_LASTNAME, user.getLastname());
        values.put(KEY_PLAN_ID, user.getPlan_id());
        values.put(KEY_PLAN_NAME, user.getPlan_name());
        values.put(KEY_PLAN_PRICE, user.getPlan_price());
        values.put(KEY_PLAN_STORAGE, user.getPlan_storage());
        values.put(KEY_PLAN_DETAILS, user.getPlan_details());
        values.put(KEY_USER_FILLED_STORAGE, user.getFilled_storage());
        values.put(KEY_USER_FILLED_STORAGE_DOC, user.getFilled_storage_doc());
        values.put(KEY_USER_FILLED_STORAGE_IMAGE, user.getFilled_storage_image());
        values.put(KEY_USER_FILLED_STORAGE_MUSIC, user.getFilled_storage_music());
        values.put(KEY_USER_FILLED_STORAGE_VIDEO, user.getFilled_storage_video());


        //Get Erase others users
        db.execSQL("delete from "+ TABLE_USER);

        // insert row
        long user_response = db.insert(TABLE_USER, null, values);

        if(user_response == -1){
            return false;
        }else{
            return true;
        }
    }

    /*
     * Creating a Activity
     */
    public Boolean addActivityDB(ActivityDB activity) {

        SQLiteDatabase db = this.getWritableDatabase();
        Boolean active;
        active = this.activeActivity();
        ContentValues values = new ContentValues();

        if (active == true){
            values.put(KEY_ID, activity.getId());
            values.put(KEY_ACTIONTYPE, activity.getActionType());
            values.put(KEY_EMAIL, activity.getEmail());
            values.put(KEY_INIT_DATE, activity.getInit_date());
            values.put(KEY_END_DATE, activity.getEnd_date());
            values.put(KEY_TOTAL_FILES, activity.getTotal_files());
            values.put(KEY_CURRENT_FILES, activity.getCurrent_files());
            values.put(KEY_DETAIL, activity.getDetail());
            values.put(KEY_BYTES, activity.getDetail());
            values.put(KEY_STATUS, "4");
        }else{
            values.put(KEY_ID, activity.getId());
            values.put(KEY_ACTIONTYPE, activity.getActionType());
            values.put(KEY_EMAIL, activity.getEmail());
            values.put(KEY_INIT_DATE, activity.getInit_date());
            values.put(KEY_END_DATE, activity.getEnd_date());
            values.put(KEY_TOTAL_FILES, activity.getTotal_files());
            values.put(KEY_CURRENT_FILES, activity.getCurrent_files());
            values.put(KEY_DETAIL, activity.getDetail());
            values.put(KEY_BYTES, activity.getDetail());
            values.put(KEY_STATUS, "1");
        }


        // insert row
        long activity_response = db.insert(TABLE_ACTIVITY, null, values);

        if(activity_response == -1){
            return false;
        }else{
            return true;
        }
    }

    /*
     * Creating a File
     */
    public Boolean addFile(FileDB file) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_ID, file.getId());
        values.put(KEY_ACTIVITYID, file.getActivityid());
        values.put(KEY_EMAIL, file.getEmail());
        values.put(KEY_FILENAME, file.getFilename());
        values.put(KEY_FILESIZE, file.getFilesize());
        values.put(KEY_FILETYPE, file.getFiletype());
        values.put(KEY_STATUS, file.getStatus());
        values.put(KEY_DETAIL, file.getDetail());
        values.put(KEY_BYTES, file.getBytes());
        values.put(KEY_PATH, file.getPath());

        // insert row
        long file_response = db.insert(TABLE_FILE, null, values);

        if(file_response == -1){
            return false;
        }else{
            return true;
        }
    }

    /*
     * get active user
     */
    public UserDB getUser() {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_USER + " WHERE "
                + KEY_STATUS + " = " + 1;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null)
            c.moveToFirst();

        if(c.getCount() > 0){
            UserDB user = new UserDB(c.getString(c.getColumnIndex(KEY_EMAIL)),
                    c.getString(c.getColumnIndex(KEY_PASS)),
                    c.getString(c.getColumnIndex(KEY_TOKEN)),
                    c.getString(c.getColumnIndex(KEY_STATUS)),
                    c.getString(c.getColumnIndex(KEY_NAME)),
                    c.getString(c.getColumnIndex(KEY_LASTNAME)),
                    c.getString(c.getColumnIndex(KEY_PLAN_ID)),
                    c.getString(c.getColumnIndex(KEY_PLAN_NAME)),
                    c.getString(c.getColumnIndex(KEY_PLAN_PRICE)),
                    c.getString(c.getColumnIndex(KEY_PLAN_STORAGE)),
                    c.getString(c.getColumnIndex(KEY_PLAN_DETAILS)),
                    c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE)),
                    c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_DOC)),
                    c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_IMAGE)),
                    c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_MUSIC)),
                    c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_VIDEO)));
            return user;
        }else{
            return null;
        }
    }

    /*
     * get active activity
     */
    public ArrayList<ActivityDB> getActivities() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<ActivityDB> activities = null;

        String selectQuery = "SELECT  * FROM " + TABLE_ACTIVITY + " WHERE status = 1 OR status = 3";

        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            activities = new ArrayList<>();
            while (!c.isAfterLast()) {
                ActivityDB activity = new ActivityDB(c.getString(c.getColumnIndex(KEY_ID)),
                        c.getString(c.getColumnIndex(KEY_ACTIONTYPE)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_INIT_DATE)),
                        c.getString(c.getColumnIndex(KEY_END_DATE)),
                        c.getString(c.getColumnIndex(KEY_TOTAL_FILES)),
                        c.getString(c.getColumnIndex(KEY_CURRENT_FILES)),
                        c.getString(c.getColumnIndex(KEY_BYTES)),
                        c.getString(c.getColumnIndex(KEY_DETAIL)),
                        c.getString(c.getColumnIndex(KEY_STATUS)));
                activities.add(activity);
                c.moveToNext();
            }
        }
        return activities;
    }

    /*
     * get active files
     */
    public ArrayList<FileDB> getFile() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<FileDB> files = null;

        String selectQuery = "SELECT  * FROM " + TABLE_FILE;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            files = new ArrayList<>();
            while (!c.isAfterLast()) {
                FileDB file = new FileDB(c.getString(c.getColumnIndex(KEY_ID)),
                        c.getString(c.getColumnIndex(KEY_ACTIVITYID)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_FILENAME)),
                        c.getString(c.getColumnIndex(KEY_FILESIZE)),
                        c.getString(c.getColumnIndex(KEY_FILETYPE)),
                        c.getString(c.getColumnIndex(KEY_STATUS)),
                        c.getString(c.getColumnIndex(KEY_DETAIL)),
                        c.getString(c.getColumnIndex(KEY_PATH)),
                        c.getString(c.getColumnIndex(KEY_BYTES)));
                files.add(file);
            }
        }
        return files;
    }

    /*
     * delete active user
     */
    public void deleteUser(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_USER);
    }

    /*
     * delete active activity
     */
    public void deleteActivityDB(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_ACTIVITY);
    }

    /*
     * delete active files
     */
    public void deleteFile(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_FILE);
    }

    /*
     * update user
     */
    public int updateUser( String email, String field, String value){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(field,value);
        //db.update returns affected rows
        if (db.update(TABLE_USER , cv, "email = ?", new String[]{email}) != 0){
            return 1;
        }
        return 0;
    }

    /*
     * update activity
     */
    public int updateActivity(String id, String field, String value){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(field,value);
        //db.update returns affected rows
        if ( db.update(TABLE_ACTIVITY,cv, "id = ?", new String[]{id}) != 0){
            return 1;
        }
        return 0;
    }

    /*
     * update file
     */
    public int updateFile(String id, String field, String value){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(field,value);
        //db.update returns affected rows
        if(db.update(TABLE_FILE, cv, "id = ?", new String[]{id}) != 0){
            return 1;
        }
        return 0;
    }


    /*
     * get activities by email
     */
    public ArrayList<ActivityDB> getActivitiesByEmail( String email ){
        ArrayList<ActivityDB> activities = null;

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_ACTIVITY + " WHERE "
                + KEY_STATUS + " = " + 1 + " AND email = " + email;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            activities = new ArrayList<>();
            while (!c.isAfterLast()) {
                ActivityDB activity = new ActivityDB(c.getString(c.getColumnIndex(KEY_ID)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_INIT_DATE)),
                        c.getString(c.getColumnIndex(KEY_END_DATE)),
                        c.getString(c.getColumnIndex(KEY_TOTAL_FILES)),
                        c.getString(c.getColumnIndex(KEY_CURRENT_FILES)),
                        c.getString(c.getColumnIndex(KEY_BYTES)),
                        c.getString(c.getColumnIndex(KEY_DETAIL)),
                        c.getString(c.getColumnIndex(KEY_STATUS)));
                activities.add(activity);
            }
        }

        return activities;
    }

    /*
     * get files by id
     */
    public ArrayList<FileDB> getFilesByActivityId( String activityid){
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<FileDB> files = null;
        UserDB userobj = this.getUser();
        Log.e("FilesActivity","PASO1");
        String selectQuery = "SELECT  * FROM " + TABLE_FILE + " WHERE "
                + KEY_STATUS + " = 1 AND activityid = " + activityid + " AND email = '"
                + userobj.getEmail() + "'";

        Cursor c = db.rawQuery(selectQuery, null);
        int init = 0;
        try {
            while (c.moveToNext()) {
                if(init == 0){
                    files = new ArrayList<FileDB>();
                    init = 1;
                }
                FileDB file = new FileDB(c.getString(c.getColumnIndex(KEY_ID)),
                        c.getString(c.getColumnIndex(KEY_ACTIVITYID)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_FILENAME)),
                        c.getString(c.getColumnIndex(KEY_FILESIZE)),
                        c.getString(c.getColumnIndex(KEY_FILETYPE)),
                        c.getString(c.getColumnIndex(KEY_STATUS)),
                        c.getString(c.getColumnIndex(KEY_DETAIL)),
                        c.getString(c.getColumnIndex(KEY_PATH)),
                        c.getString(c.getColumnIndex(KEY_BYTES)));
                files.add(file);
            }
        } finally {
            c.close();
        }
        return files;
    }

    /*
     * Delete files by activity id
     */
    public Boolean deleteFilesByActivityId(String activityid){
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<FileDB> files = null;
        UserDB userobj = this.getUser();
        Log.e("FilesActivity","PASO1");
        String selectQuery = "SELECT  * FROM " + TABLE_FILE + " WHERE "
                + KEY_STATUS + " = 1 AND activityid = " + activityid + " AND email = '"
                + userobj.getEmail() + "'";
        Boolean status = true;

        Cursor c = db.rawQuery(selectQuery, null);
        int init = 0;
        try {
            while (c.moveToNext()) {
                if(init == 0){
                    init = 1;
                }
                db.delete(TABLE_FILE, "id = ?", new String[]{c.getString(c.getColumnIndex(KEY_ID))});
            }
        } finally {
            c.close();
        }
        return status;
    }

    /*
     * Cancel activity by id
     */
    public Boolean cancelActivity(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase dbFile = this.getWritableDatabase();
        ArrayList<FileDB> files;
        //db.update returns affected rows
        db.beginTransaction();
        try {
            if ( db.delete(TABLE_ACTIVITY, "id = ?", new String[]{id}) != 0){
                files = getFilesByActivityId(id);
                if(files != null){
                    if( deleteFilesByActivityId(id)) {
                        db.setTransactionSuccessful();
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }

            db.setTransactionSuccessful();
            return false;
        } finally {
            db.endTransaction();
        }
    }

    /*
     * Pause activity by id
     */
    public Boolean pauseActivity(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_STATUS,3);
        //db.update returns affected rows
        if ( db.update(TABLE_ACTIVITY,cv, "id = ?", new String[]{id}) != 0){
            return true;
        }
        return false;
    }

    /*
     * Play activity by id
     */
    public Boolean playActivity(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase db1 = this.getReadableDatabase();
        ContentValues cv = new ContentValues();
        Boolean active = false;

        //Verify if another activity is on
        String selectQuery = "SELECT  * FROM " + TABLE_ACTIVITY + " WHERE status = 1";

        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            while (!c.isAfterLast()) {
                active = true;
            }
        }
        if(!active){
            //If everything is ok, then we go
            cv.put(KEY_STATUS,1);
            //db.update returns affected rows
            if ( db.update(TABLE_ACTIVITY,cv, "id = ?", new String[]{id}) != 0){
                return true;
            }
        }
        return false;
    }

    /*
     * get active activity
     */
    public ActivityDB getActivityById(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ActivityDB activityNode = null;

        String selectQuery = "SELECT  * FROM " + TABLE_ACTIVITY + " WHERE id=" + id + " AND status = 1";

        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            while (!c.isAfterLast()) {
                    activityNode = new ActivityDB(c.getString(c.getColumnIndex(KEY_ID)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_INIT_DATE)),
                        c.getString(c.getColumnIndex(KEY_END_DATE)),
                        c.getString(c.getColumnIndex(KEY_TOTAL_FILES)),
                        c.getString(c.getColumnIndex(KEY_CURRENT_FILES)),
                        c.getString(c.getColumnIndex(KEY_BYTES)),
                        c.getString(c.getColumnIndex(KEY_DETAIL)),
                        c.getString(c.getColumnIndex(KEY_STATUS)));
                c.moveToNext();
            }
        }
        return activityNode;
    }

    /*
     * Pull Data from server
     */
    public void pullData(Context context) throws JSONException {
        UserDB user = this.getUser();
        JSONObject json = new JSONObject();
        json.put("email",user.getEmail());
        String url = context.getResources().getString(R.string.api_url);
        PullDataRequest pull = new PullDataRequest(url, String.valueOf(json));
        pull.execute();
    }

    /*
     * Push Data to server
     */
    public void pushData(Context context) throws JSONException {

        SQLiteDatabase db = this.getReadableDatabase();
        UserDB user = null;
        ArrayList<ActivityDB> activities = null;
        ArrayList<FileDB> files = null;
        JSONObject data = new JSONObject();
        JSONArray activityArray = null;
        JSONArray fileArray = null;
        JSONObject activity;
        JSONObject file;
        String url = context.getResources().getString(R.string.api_url);

        activities = getActivities();

        if (activities != null){

            activityArray = new JSONArray();
            for(int i = 0; i < activities.size(); i ++){

                activity = new JSONObject();
                activity.put("id",activities.get(i).getId());
                activity.put("init_date",activities.get(i).getActionType());
                activity.put("init_date",activities.get(i).getInit_date());
                activity.put("end_date",activities.get(i).getEnd_date());
                activity.put("total_files",activities.get(i).getTotal_files());
                activity.put("current_files",activities.get(i).getCurrent_files());
                activity.put("detail",activities.get(i).getDetail());
                activity.put("bytes",activities.get(i).getBytes());
                activity.put("bytes",activities.get(i).getStatus());
                files = getFilesByActivityId(activities.get(i).getId());

                if (files != null){
                    fileArray = new JSONArray();

                    for(int j = 0; j < files.size(); j ++){
                        file = new JSONObject();
                        file.put("id",files.get(j).getId());
                        file.put("activityid",activities.get(i).getId());
                        file.put("filename",files.get(j).getFilename());
                        file.put("filesize",files.get(j).getFilesize());
                        file.put("filetype",files.get(j).getFiletype());
                        file.put("status",files.get(j).getStatus());
                        file.put("status",files.get(j).getDetail());
                        file.put("bytes",files.get(j).getBytes());
                        file.put("path",files.get(j).getPath());
                        fileArray.put(file);
                    }
                }
                activity.put("files",fileArray);
                activityArray.put(activity);
                fileArray = null;
            }
        }
        user = this.getUser();
        data.put("activities",activityArray);

        data.put("email",user.getEmail());

        PushDataRequest request = new PushDataRequest(url , String.valueOf(data));
        request.execute();
    }

    public class PushDataRequest extends AsyncTask<Void, Void, Void> {

        String json;
        String url;

        public PushDataRequest( String url, String json){
            this.url = url;
            this.json = json;

            //Descomentar esto para ver logs de servidor
                HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
                interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
                OkHttpClient client_log = new OkHttpClient.Builder().addInterceptor(interceptor).build();

            OkHttpClient client_2 = new OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.MINUTES)
                    .readTimeout(10,TimeUnit.MINUTES).build();

            //Create Retrofit instance
            Retrofit.Builder builder = new Retrofit.Builder()
                    //Descomentar para ver logs
                    .client(client_2)
                    .baseUrl(url)
                    .addConverterFactory(GsonConverterFactory.create());

            Retrofit retrofit = builder.build();

            //Get client &  call object for the request
            UserClient client = retrofit.create(UserClient.class);

            //Finally, execute the request
            Call<ResponseBody> call = client.pushData(this.json);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                        Toast.makeText(UploadFilesManually.this, "Yeah!" + response, Toast.LENGTH_LONG).show();
                    Log.v("Respuesta del servidor", String.valueOf(response));
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
//                        Toast.makeText(UploadFilesManually.this, "nooo :(", Toast.LENGTH_LONG).show();
                    Log.e("Error", String.valueOf(t));
                }
            });
        }

        @Override
        protected Void doInBackground(Void... voids) {
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    public class PullDataRequest extends AsyncTask<Void, Void, Void> {

        String json;
        String url;

        public PullDataRequest( String url , String json){
            this.url = url;
            this.json = json;

            //Descomentar esto para ver logs de servidor
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient client_log = new OkHttpClient.Builder().addInterceptor(interceptor).build();

            OkHttpClient client_2 = new OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.MINUTES)
                    .readTimeout(10,TimeUnit.MINUTES).build();

            //Create Retrofit instance
            Retrofit.Builder builder = new Retrofit.Builder()
                    //Descomentar para ver logs
                    .client(client_2)
                    .baseUrl(url)
                    .addConverterFactory(GsonConverterFactory.create());

            Retrofit retrofit = builder.build();

            //Get client &  call object for the request
            UserClient client = retrofit.create(UserClient.class);

            //Finally, execute the request
            Call<ResponseBody> call = client.pullData(this.json);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                        Toast.makeText(UploadFilesManually.this, "Yeah!" + response, Toast.LENGTH_LONG).show();
                    try {
                        Log.v("Respuesta del servidor", String.valueOf(response.body().string()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
//                        Toast.makeText(UploadFilesManually.this, "nooo :(", Toast.LENGTH_LONG).show();
                    Log.e("Error", String.valueOf(t));
                }
            });
        }

        @Override
        protected Void doInBackground(Void... voids) {
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }
    }

    /*
     * Function to check if there's an active activity
     */
    public Boolean activeActivity(){
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_ACTIVITY + " WHERE "
                + KEY_STATUS + " = 1 ";

        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToNext()) {
            return true;
        }

        return false;
    }

    /*
     * Function to check if there's an active activity
     */
    public String getActivityProgress(String id){
        SQLiteDatabase db = this.getReadableDatabase();
        ActivityDB activityNode = null;
        String percentage;

        String selectQuery = "SELECT  * FROM " + TABLE_ACTIVITY + " WHERE id=" + id + " AND status = 1";

        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            while (!c.isAfterLast()) {
                activityNode = new ActivityDB(c.getString(c.getColumnIndex(KEY_ID)),
                        c.getString(c.getColumnIndex(KEY_ACTIONTYPE)),
                        c.getString(c.getColumnIndex(KEY_EMAIL)),
                        c.getString(c.getColumnIndex(KEY_INIT_DATE)),
                        c.getString(c.getColumnIndex(KEY_END_DATE)),
                        c.getString(c.getColumnIndex(KEY_TOTAL_FILES)),
                        c.getString(c.getColumnIndex(KEY_CURRENT_FILES)),
                        c.getString(c.getColumnIndex(KEY_BYTES)),
                        c.getString(c.getColumnIndex(KEY_DETAIL)),
                        c.getString(c.getColumnIndex(KEY_STATUS)));
                c.moveToNext();
            }
        }
        return "";
    }

    public void addUploadStorage(double storage, int filetype){

        //Para leer primero el tamaño inicial
        SQLiteDatabase db_read = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_USER + " WHERE "
                + KEY_STATUS + " = " + 1;

        Cursor c = db_read.rawQuery(selectQuery, null);

        if (c != null)
            c.moveToFirst();

        UserDB user = new UserDB(c.getString(c.getColumnIndex(KEY_EMAIL)),
                c.getString(c.getColumnIndex(KEY_PASS)),
                c.getString(c.getColumnIndex(KEY_TOKEN)),
                c.getString(c.getColumnIndex(KEY_STATUS)),
                c.getString(c.getColumnIndex(KEY_NAME)),
                c.getString(c.getColumnIndex(KEY_LASTNAME)),
                c.getString(c.getColumnIndex(KEY_PLAN_ID)),
                c.getString(c.getColumnIndex(KEY_PLAN_NAME)),
                c.getString(c.getColumnIndex(KEY_PLAN_PRICE)),
                c.getString(c.getColumnIndex(KEY_PLAN_STORAGE)),
                c.getString(c.getColumnIndex(KEY_PLAN_DETAILS)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_DOC)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_IMAGE)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_MUSIC)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_VIDEO)));

        //Para modificar en la base de datos
        SQLiteDatabase db_write = this.getWritableDatabase();

        //calculos
        double full_storage_db = Double.parseDouble(user.getFilled_storage());
        double full_storage_db_final = full_storage_db + storage;

        ContentValues values = new ContentValues();
        values.put(KEY_USER_FILLED_STORAGE, full_storage_db_final);

        if(filetype == 1){
            //Imagen
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_image());
            double full_storage_other_db_final = full_storage_other_db + storage;
            values.put(KEY_USER_FILLED_STORAGE_IMAGE, String.valueOf(full_storage_other_db_final));
        }else if(filetype == 2){
            //Video
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_video());
            double full_storage_other_db_final = full_storage_other_db + storage;
            values.put(KEY_USER_FILLED_STORAGE_VIDEO, String.valueOf(full_storage_other_db_final));
        }else if(filetype == 3){
            //Audio
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_music());
            double full_storage_other_db_final = full_storage_other_db + storage;
            values.put(KEY_USER_FILLED_STORAGE_MUSIC, String.valueOf(full_storage_other_db_final));
        }else if(filetype == 4){
            //Documentos
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_doc());
            double full_storage_other_db_final = full_storage_other_db + storage;
            values.put(KEY_USER_FILLED_STORAGE_DOC, String.valueOf(full_storage_other_db_final));
        }

        db_write.update(TABLE_USER, values, KEY_STATUS + "=" + 1, null);
    }


    public void deleteUploadStorage(String str_storage, String str_filetype){

        //Para leer primero el tamaño inicial
        SQLiteDatabase db_read = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_USER + " WHERE "
                + KEY_STATUS + " = " + 1;

        Cursor c = db_read.rawQuery(selectQuery, null);


        double storage = Double.parseDouble(str_storage);
        int filetype = Integer.parseInt(str_filetype);

        if (c != null)
            c.moveToFirst();

        UserDB user = new UserDB(c.getString(c.getColumnIndex(KEY_EMAIL)),
                c.getString(c.getColumnIndex(KEY_PASS)),
                c.getString(c.getColumnIndex(KEY_TOKEN)),
                c.getString(c.getColumnIndex(KEY_STATUS)),
                c.getString(c.getColumnIndex(KEY_NAME)),
                c.getString(c.getColumnIndex(KEY_LASTNAME)),
                c.getString(c.getColumnIndex(KEY_PLAN_ID)),
                c.getString(c.getColumnIndex(KEY_PLAN_NAME)),
                c.getString(c.getColumnIndex(KEY_PLAN_PRICE)),
                c.getString(c.getColumnIndex(KEY_PLAN_STORAGE)),
                c.getString(c.getColumnIndex(KEY_PLAN_DETAILS)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_DOC)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_IMAGE)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_MUSIC)),
                c.getString(c.getColumnIndex(KEY_USER_FILLED_STORAGE_VIDEO)));

        //Para modificar en la base de datos
        SQLiteDatabase db_write = this.getWritableDatabase();

        //calculos
        double full_storage_db = Double.parseDouble(user.getFilled_storage());
        double full_storage_db_final = full_storage_db - storage;

        ContentValues values = new ContentValues();
        values.put(KEY_USER_FILLED_STORAGE, full_storage_db_final);

        if(filetype == 1){
            //Imagen
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_image());
            double full_storage_other_db_final = full_storage_other_db - storage;
            values.put(KEY_USER_FILLED_STORAGE_IMAGE, String.valueOf(full_storage_other_db_final));
        }else if(filetype == 2){
            //Video
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_video());
            double full_storage_other_db_final = full_storage_other_db - storage;
            values.put(KEY_USER_FILLED_STORAGE_VIDEO, String.valueOf(full_storage_other_db_final));
        }else if(filetype == 3){
            //Audio
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_music());
            double full_storage_other_db_final = full_storage_other_db - storage;
            values.put(KEY_USER_FILLED_STORAGE_MUSIC, String.valueOf(full_storage_other_db_final));
        }else if(filetype == 4){
            //Documentos
            double full_storage_other_db = Double.parseDouble(user.getFilled_storage_doc());
            double full_storage_other_db_final = full_storage_other_db - storage;
            values.put(KEY_USER_FILLED_STORAGE_DOC, String.valueOf(full_storage_other_db_final));
        }

        db_write.update(TABLE_USER, values, KEY_STATUS + "=" + 1, null);
    }

    // closing database
    public void closeDB() {
        SQLiteDatabase db = this.getReadableDatabase();
        if (db != null && db.isOpen())
            db.close();
    }
}
package com.example.autumn.kustody.api.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by anibalsci on 28-09-17.
 */

public class UserData {

    @SerializedName("token")
    public String token;

    @SerializedName("name")
    public String name;

    @SerializedName("lastname")
    public String lastname;

    @SerializedName("email")
    public String email;

    @SerializedName("password")
    public String password;

    @SerializedName("plan_id")
    public String plan_id;

    @SerializedName("plan_name")
    public String plan_name;

    @SerializedName("plan_price")
    public String plan_price;

    @SerializedName("plan_storage")
    public String plan_storage;

    @SerializedName("plan_details")
    public String plan_details;

    @SerializedName("filled_storage")
    public String filled_storage;

    @SerializedName("filled_storage_image")
    public String filled_storage_image;

    @SerializedName("filled_storage_video")
    public String filled_storage_video;

    @SerializedName("filled_storage_music")
    public String filled_storage_music;

    @SerializedName("filled_storage_doc")
    public String filled_storage_doc;

    public UserData(String name, String lastname, String email, String password) {
        this.name = name;
        this.lastname = lastname;
        this.email = email;
        this.password = password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPlan_id() {
        return plan_id;
    }

    public void setPlan_id(String plan_id) {
        this.plan_id = plan_id;
    }

    public String getPlan_name() {
        return plan_name;
    }

    public void setPlan_name(String plan_name) {
        this.plan_name = plan_name;
    }

    public String getPlan_price() {
        return plan_price;
    }

    public void setPlan_price(String plan_price) {
        this.plan_price = plan_price;
    }

    public String getPlan_storage() {
        return plan_storage;
    }

    public void setPlan_storage(String plan_storage) {
        this.plan_storage = plan_storage;
    }

    public String getPlan_details() {
        return plan_details;
    }

    public void setPlan_details(String plan_details) {
        this.plan_details = plan_details;
    }

    public String getFilled_storage() {
        return filled_storage;
    }

    public void setFilled_storage(String filled_storage) {
        this.filled_storage = filled_storage;
    }

    public String getFilled_storage_image() {
        return filled_storage_image;
    }

    public void setFilled_storage_image(String filled_storage_image) {
        this.filled_storage_image = filled_storage_image;
    }

    public String getFilled_storage_video() {
        return filled_storage_video;
    }

    public void setFilled_storage_video(String filled_storage_video) {
        this.filled_storage_video = filled_storage_video;
    }

    public String getFilled_storage_music() {
        return filled_storage_music;
    }

    public void setFilled_storage_music(String filled_storage_music) {
        this.filled_storage_music = filled_storage_music;
    }

    public String getFilled_storage_doc() {
        return filled_storage_doc;
    }

    public void setFilled_storage_doc(String filled_storage_doc) {
        this.filled_storage_doc = filled_storage_doc;
    }
}

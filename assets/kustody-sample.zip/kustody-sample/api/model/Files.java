package com.example.autumn.kustody.api.model;

/**
 * Created by anibalsci on 18-10-17.
 */

public class Files {

    private String id;
    private String email;
    private String filename;
    private String filesize;
    private String filetype;
    private String last_mod;
    private String status;
    private String detail;
    private String anyfile;
    private boolean selected;

    public Files(String id, String email, String filename, String filesize, String filetype, String last_mod, String status, String detail, String anyfile) {
        this.id = id;
        this.email = email;
        this.filename = filename;
        this.filesize = filesize;
        this.filetype = filetype;
        this.last_mod = last_mod;
        this.status = status;
        this.detail = detail;
        this.anyfile = anyfile;
        this.selected = false;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilesize() {
        return filesize;
    }

    public void setFilesize(String filesize) {
        this.filesize = filesize;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public String getLast_mod() {
        return last_mod;
    }

    public void setLast_mod(String last_mod) {
        this.last_mod = last_mod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getAnyfile() {
        return anyfile;
    }

    public void setAnyfile(String anyfile) {
        this.anyfile = anyfile;
    }

    public boolean getSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}

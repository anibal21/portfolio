package com.example.autumn.kustody.api.model;

/**
 * Created by anibalsci on 07-12-17.
 */

public class Token
{
    private String token;

    public String getToken ()
    {
        return token;
    }

    public void setToken (String token)
    {
        this.token = token;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [token = "+token+"]";
    }
}

package com.example.autumn.kustody.api.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by jaimearavena on 15-12-17.
 */

public class UserProfile {

    @SerializedName("name")
    public String name;

    @SerializedName("lastname")
    public String lastname;

    @SerializedName("email")
    public String email;

    @SerializedName("password")
    public String password;

    @SerializedName("url_image")
    public String url_image;

    @SerializedName("plan_id")
    public String plan_id;

    public UserProfile(String name, String lastname, String email, String password, String url_image, String plan_id) {
        this.name = name;
        this.lastname = lastname;
        this.email = email;
        this.password = password;
        this.url_image = url_image;
        this.plan_id = plan_id;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUrl_image() {
        return url_image;
    }

    public void setUrl_image(String url_image) {
        this.url_image = url_image;
    }

    public String getPlan_id() {
        return plan_id;
    }

    public void setPlan_id(String plan_id) {
        this.plan_id = plan_id;
    }
}
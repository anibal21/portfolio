package com.example.autumn.kustody.api.service;

import com.example.autumn.kustody.api.model.Files;
import com.example.autumn.kustody.api.model.UserData;
import com.example.autumn.kustody.api.model.UserProfile;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by anibalsci on 28-09-17.
 */

public interface UserClient {


    @Headers({
            "Content-Type: application/json",
            "Vary: Accept"
    })

    //Para registrar usuarios
    @POST("profile/")
    Call<UserProfile> createAccount(@Body UserProfile userData);

    //Para iniciar sesión
    @FormUrlEncoded
    @POST("login/")
    Call<UserData> login(@Field("username") String username, @Field("password") String password);

    @Multipart
    @POST("image-upload/")
    Call<ResponseBody> uploadPhoto(
            @Part("detail") RequestBody detail,
            @Part MultipartBody.Part image
    );

    @Multipart
    @POST("multi-upload/")
    Call<ResponseBody> uploadFile(
            @Header("Authorization") String auth,
            @Part("email") RequestBody email,
            @Part("filename") RequestBody filename,
            @Part("filesize") RequestBody filesize,
            @Part("filetype") RequestBody filetype,
            @Part("status") RequestBody status,
            @Part("detail") RequestBody detail,
            @Part MultipartBody.Part anyfile
    );

    @GET("{url}") //  the string in the GET is end part of the endpoint url
    Call<List<Files>> listCloudFiles_all(@Header("Authorization") String auth,
                                         @Path("url")String url);

    @GET("{url}") //  the string in the GET is end part of the endpoint url
    Call<List<Files>> listCloudFiles_bytype(@Header("Authorization") String auth,
                                            @Path("url")String url,
                                            @Query("filetype") String filetype);
    @GET("{url}")
    Call<ResponseBody> downloadFile(@Path("url")String url);

    @FormUrlEncoded
    @POST("delete_file/")
    Call<ResponseBody> deleteFromServer(@Field("filename") String filename,
                                        @Field("email") String email);

    @FormUrlEncoded
    @POST("push-data/")
    Call<ResponseBody> pushData(@Field("json") String json);

    @FormUrlEncoded
    @POST("pull-data/")
    Call<ResponseBody> pullData(@Field("json") String json);
}
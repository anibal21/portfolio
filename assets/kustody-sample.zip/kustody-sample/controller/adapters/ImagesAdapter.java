package com.example.autumn.kustody.controller.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.example.autumn.kustody.R;
import com.example.autumn.kustody.controller.media_classes.ImageFile;

import java.util.ArrayList;

public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.ViewHolder> {
    private ArrayList<ImageFile> lista_fotos;
    private Context context;
    private long totalSizeImages;
    private SendDataImages mCallback;

    public ImagesAdapter(Context context, ArrayList<ImageFile> fotos_external, SendDataImages listener) {
        this.context = context;
        this.lista_fotos = fotos_external;
        this.mCallback = listener;
    }

    @Override
    public ImagesAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gridview_custom_images, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ImagesAdapter.ViewHolder viewHolder, final int i) {
        Glide.with(context)
                .load(lista_fotos.get(i).getImage_path())
                .into(viewHolder.img);


        if(!lista_fotos.get(i).getAutomatic_mode()) {
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                if (!lista_fotos.get(i).getSelected()) {
                    viewHolder.checkBox.setImageResource(R.drawable.checkbox2);
                    lista_fotos.get(i).setSelected(true);
                    increment(i);
                } else {
                    viewHolder.checkBox.setImageResource(R.drawable.checkbox2_1);
                    lista_fotos.get(i).setSelected(false);
                    decrement(i);
                }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return lista_fotos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView title;
        private ImageView checkBox;
        private ImageView img;

        public ViewHolder(View view) {
            super(view);
            img = (ImageView) view.findViewById(R.id.img_thumb);
            checkBox = view.findViewById(R.id.checkbox_videos);
        }
    }

    public interface SendDataImages {
        void sendDataImages (long value);
    }

    public void increment(int i){
        totalSizeImages = totalSizeImages + lista_fotos.get(i).getImage_size_long();
        mCallback.sendDataImages(totalSizeImages);
    }

    public void decrement(int i){
        totalSizeImages = totalSizeImages - lista_fotos.get(i).getImage_size_long();
        mCallback.sendDataImages(totalSizeImages);
    }
}
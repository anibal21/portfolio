package com.facilito.autumn.facilito.controller;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.facilito.autumn.facilito.R;
import com.facilito.autumn.facilito.utils.Product;
import java.util.ArrayList;

/**
 * Created by jaimearavena on 03-01-18.
 */

public class ShopProductCardAdapter extends RecyclerView.Adapter<ShopProductCardAdapter.MyViewHolder> {

    private Context mContext;
    private ArrayList<Product> albumList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView product_name, product_price, shop_name;
        public ImageView product_image;

        public MyViewHolder(View view) {
            super(view);
            product_name = (TextView) view.findViewById(R.id.card_product_shop_tv_name);
            product_price = (TextView) view.findViewById(R.id.card_product_shop_tv_price);
            product_image = (ImageView) view.findViewById(R.id.card_product_shop_iv_image);
        }
    }


    public ShopProductCardAdapter(Context mContext, ArrayList<Product> cardList) {
        this.mContext = mContext;
        this.albumList = cardList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_product_shop_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        Product card = albumList.get(position);

        holder.product_name.setText(card.getProduct_name());
        holder.product_price.setText("$"+card.getProduct_price());

        // loading album cover using Glide library
        Glide.with(mContext).load( card.getProduct_image()).into(holder.product_image);

    }
    @Override
    public int getItemCount() {
        return albumList.size();
    }
}


package com.facilito.autumn.facilito.controller;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facilito.autumn.facilito.R;
import com.facilito.autumn.facilito.utils.Category;
import com.facilito.autumn.facilito.utils.Shop;

import java.util.List;


/**
 * Created by jaimearavena on 03-01-18.
 */

public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.MyViewHolder> {

    private Context mContext;
    private List<Category> albumList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView category_name;
        public ImageView category_image;

        public MyViewHolder(View view) {
            super(view);

            category_name = (TextView) view.findViewById(R.id.categories_card_title);
            category_image = (ImageView) view.findViewById(R.id.categories_card_image);
        }
    }

    public CategoriesAdapter(Context mContext, List<Category> cardList) {
        this.mContext = mContext;
        this.albumList = cardList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_category_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        Category card = albumList.get(position);

        holder.category_name.setText(card.getCategory_name());

        //Poner logo según la id que llegue
        // loading album cover using Glide library
        Glide.with(mContext).load(card.getCategory_image()).into(holder.category_image);
    }
    @Override
    public int getItemCount() {
        return albumList.size();
    }
}


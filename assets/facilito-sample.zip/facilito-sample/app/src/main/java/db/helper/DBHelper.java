package com.facilito.autumn.facilito.db.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.facilito.autumn.facilito.db.modem.UserDB;


public class DBHelper extends SQLiteOpenHelper {

    // Logcat tag
    private static final String LOG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 8;

    // Database Name
    private static final String DATABASE_NAME = "facilito";

    // Table Names
    private static final String TABLE_USER = "user";

    // Common column names
    private static final String KEY_STATUS = "status";

    // USER Table - column names
    private static final String KEY_ID_USER = "id_user";
    private static final String KEY_EMAIL_USER = "email";
    private static final String KEY_NAME_USER = "name";
    private static final String KEY_LASTNAME_USER = "lastname";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_ID_SHOP = "id_shop";
    private static final String KEY_SELLER_STATUS = "seller_status";
    private static final String KEY_PROVIDER_STATUS = "provider_status";
    private static final String KEY_URL_USER = "url_user";
    private static final String KEY_URL_USERNAME = "username";
    private static final String KEY_URL_PHONE = "phone";

    // USER table create statement
    private static final String CREATE_TABLE_USER = "CREATE TABLE " + TABLE_USER
            + "(" + KEY_ID_USER + " TEXT PRIMARY KEY," +
            KEY_EMAIL_USER + " TEXT," +
            KEY_PASSWORD + " TEXT," +
            KEY_NAME_USER + " TEXT," +
            KEY_LASTNAME_USER + " TEXT," +
            KEY_ID_SHOP + " TEXT, " +
            KEY_SELLER_STATUS + " TEXT, " +
            KEY_PROVIDER_STATUS + " TEXT, " +
            KEY_URL_USER + " TEXT, " +
            KEY_URL_USERNAME + " TEXT, " +
            KEY_URL_PHONE + " TEXT)";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // creating required tables
        db.execSQL(CREATE_TABLE_USER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // on upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);

        // create new tables
        onCreate(db);
    }

    /*
     * Creating a UserData
     */
    public long addUser(UserDB user) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_ID_USER, user.getId_user());
        values.put(KEY_EMAIL_USER, user.getEmail());
        values.put(KEY_NAME_USER, user.getName());
        values.put(KEY_LASTNAME_USER, user.getLastname());
        values.put(KEY_PASSWORD, user.getPassword());
        values.put(KEY_ID_SHOP, user.getId_shop());
        values.put(KEY_SELLER_STATUS, user.getSeller_status());
        values.put(KEY_PROVIDER_STATUS, user.getProvider_status());
        values.put(KEY_URL_USER, user.getUrl_user());
        values.put(KEY_URL_USERNAME, user.getUsername());
        values.put(KEY_URL_PHONE, user.getPhone());

        //Get Erase others users
        db.execSQL("delete from "+ TABLE_USER);

        // insert row
        long user_response = db.insert(TABLE_USER, null, values);

        return user_response;
    }

    /*
    * get active user
    */
    public UserDB getUser() {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_USER;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null)
            c.moveToFirst();

        if(c.getCount() > 0){
            UserDB user = new UserDB(c.getString(c.getColumnIndex(KEY_ID_USER)),
                    c.getString(c.getColumnIndex(KEY_EMAIL_USER)),
                    c.getString(c.getColumnIndex(KEY_PASSWORD)),
                    c.getString(c.getColumnIndex(KEY_ID_SHOP)),
                    c.getString(c.getColumnIndex(KEY_SELLER_STATUS)),
                    c.getString(c.getColumnIndex(KEY_PROVIDER_STATUS)),
                    c.getString(c.getColumnIndex(KEY_NAME_USER)),
                    c.getString(c.getColumnIndex(KEY_LASTNAME_USER)),
                    c.getString(c.getColumnIndex(KEY_URL_USER)),
                    c.getString(c.getColumnIndex(KEY_URL_USERNAME)),
                    c.getString(c.getColumnIndex(KEY_URL_PHONE)));
            return user;
        }else{
            return null;
        }
    }

    public void deleteUser(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_USER);
    }

    // closing database
    public void closeDB() {
        SQLiteDatabase db = this.getReadableDatabase();
        if (db != null && db.isOpen())
            db.close();
    }
}

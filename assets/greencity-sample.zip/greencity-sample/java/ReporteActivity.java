package com.ideas.autumn.greencity.Reporte;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ideas.autumn.greencity.BuildConfig;
import com.ideas.autumn.greencity.MapActivity;
import com.ideas.autumn.greencity.Modelo.Base64;
import com.ideas.autumn.greencity.Modelo.ConnectionDetector;
import com.ideas.autumn.greencity.Modelo.DoFileUpload;
import com.ideas.autumn.greencity.Modelo.RequestPackage;
import com.ideas.autumn.greencity.R;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;

import static android.os.Build.VERSION_CODES.JELLY_BEAN;
import static android.os.Build.VERSION_CODES.KITKAT_WATCH;
import static android.os.Build.VERSION_CODES.M;


public class ReporteActivity extends AppCompatActivity implements View.OnClickListener {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int CAMERA_PIC_REQUEST = 1111;
    private static final String IMAGE_CAPTURE_FOLDER = "/uploads";
    private static final int CAMERA_REQUEST = 1888;
    //Camera variables
    private static final int MY_REQUEST_CODE = 1;
    public static String URL = "https://www.autumnideas.com/greenmate/image.php";
    private static Uri _imagefileUri = null;  // en un principio el Uri de la foto será null
    private static String _bytes64Sting, _imageFileName;
    Button photoButton, enviar;
    ImageView button1;
    ImageView button2;
    ImageView button3;
    Boolean picture = false;
    String imagepath = "";
    String fname;
    File file;
    String mCurrentPhotoPath;
    Boolean pla, vid, car, alu, reciclaje;
    private String estado_contenedor = null;  // el estado del contenedor será en un principio null
    View.OnClickListener imgButtonHandler1 = new View.OnClickListener() {

        public void onClick(View v) {
            button1.setImageResource(R.drawable.vacio_iconohdpi_seleccionado);
            button2.setImageResource(R.drawable.medio_iconohdpi);
            button3.setImageResource(R.drawable.lleno_iconohdpi);
            estado_contenedor = "-1";
        }
    };
    View.OnClickListener imgButtonHandler2 = new View.OnClickListener() {

        public void onClick(View v) {
            button1.setImageResource(R.drawable.vacio_iconohdpi);
            button2.setImageResource(R.drawable.medio_iconohdpi_seleccionado);
            button3.setImageResource(R.drawable.lleno_iconohdpi);
            estado_contenedor = "0";
        }
    };
    View.OnClickListener imgButtonHandler3 = new View.OnClickListener() {

        public void onClick(View v) {
            button1.setImageResource(R.drawable.vacio_iconohdpi);
            button2.setImageResource(R.drawable.medio_iconohdpi);
            button3.setImageResource(R.drawable.lleno_iconohdpi_seleccionado);
            estado_contenedor = "1";
        }
    };
    View.OnClickListener imgButtonHandler4 = new View.OnClickListener() {

        public void onClick(View v) {
            button1.setImageResource(R.drawable.vacio_iconohdpi);
            button2.setImageResource(R.drawable.medio_iconohdpi);
            button3.setImageResource(R.drawable.lleno_iconohdpi);
            estado_contenedor = "2";  // estado desaparecido
            Toast.makeText(getApplicationContext(), "Se reportará desaparecido", Toast.LENGTH_SHORT).show();
        }
    };
    private String[] arraySpinner;
    private ImageView imageView;
    private TextView textView5; // texview para visualizar información del contenedor
    private Button desaparecido; //botón que reporta al contenedor como desaparecido
    private ImageView ivImage;
    private ConnectionDetector cd;
    private Boolean upflag = false;
    private Uri selectedImage = null;
    private Bitmap bitmap, bitmapRotate;
    private ProgressDialog pDialog;
    //Variables del Activity anterior
    private String marker_title = "";
    private String marker_snippet = "";
    private String marker_name = "";
    //Metodos Camara
    private String marker_type_id = "";
    private String marker_id = "";
    private String SEVER_URL = "https://www.autumnideas.com/greenmate/uploadReport.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reporte);
        getWindow().setBackgroundDrawableResource(R.drawable.gradient);
        //Allowing Strict mode policy for Nougat support  -----------------------Cambios Ale----------------
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());


        if (Build.VERSION.SDK_INT >= M) {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {

                if (Build.VERSION.SDK_INT >= M) {
                    requestPermissions(new String[]{
                                    Manifest.permission.CAMERA,
                                    Manifest.permission.READ_EXTERNAL_STORAGE,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MY_REQUEST_CODE);
                }
            }
        }
        cd = new ConnectionDetector(ReporteActivity.this);

        //Botón que saca la fotografía
        photoButton = (Button) this.findViewById(R.id.button_photo);
        //botón para subir los datos
        enviar = (Button) this.findViewById(R.id.button_siguiente_formulario);
        ivImage = (ImageView) findViewById(R.id.ivImage);
        //ivImage.setVisibility(View.INVISIBLE);
        cd = new ConnectionDetector(getApplicationContext());

        photoButton.setOnClickListener(this);
        enviar.setOnClickListener(this);


        //Inicializamos variables del activity anterior
        Bundle bundle = getIntent().getExtras();
        marker_name = bundle.getString("marker_name");
        marker_snippet = bundle.getString("marker_snippet");
        marker_title = bundle.getString("marker_title");
        marker_type_id = bundle.getString("marker_type_id");
        marker_id = bundle.getString("marker_id");
        pla = bundle.getBoolean("plastico");
        vid = bundle.getBoolean("vidrio");
        car = bundle.getBoolean("papelycarton");
        alu = bundle.getBoolean("aluminio");
        reciclaje = bundle.getBoolean("reciclaje");

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        _imageFileName = String.valueOf("img-" + date.toString() + "Nombre del punto-" + marker_title); //agregamos el nombre del punto

        textView5 = (TextView) findViewById(R.id.textView11);
        textView5.setText("Tipo de Basurero: ".concat(marker_name.concat("\nNombre Marcador: ".concat(marker_title.concat("\n".concat(marker_snippet))))));

        button1 = (ImageView) findViewById(R.id.boton_vacio);
        button1.setOnClickListener(imgButtonHandler1);

        button2 = (ImageView) findViewById(R.id.boton_medio);
        button2.setOnClickListener(imgButtonHandler2);

        button3 = (ImageView) findViewById(R.id.boton_lleno);
        button3.setOnClickListener(imgButtonHandler3);

        desaparecido = (Button) findViewById(R.id.button5);
        desaparecido.setOnClickListener(imgButtonHandler4);
    }

    private void captureImage() {
        Intent intent = new Intent(
                android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (Build.VERSION.SDK_INT > M) {
            if (intent.resolveActivity(getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFileNougat();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    return;
                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    try {
                        _imagefileUri = FileProvider.getUriForFile(ReporteActivity.this,
                                BuildConfig.APPLICATION_ID + ".provider",
                                createImageFileNougat());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } else {
            try {
                _imagefileUri = Uri.fromFile(getFile());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        intent.putExtra(MediaStore.EXTRA_OUTPUT, _imagefileUri);
        startActivityForResult(intent, CAMERA_PIC_REQUEST);
    }

    private File createImageFileNougat() throws IOException {
        // Create an image file name
        File storageDir = new File(Environment.getExternalStorageDirectory(), "/uploads");
        boolean success = true;
        if (!storageDir.exists()) {
            //Toast.makeText(MainActivity.this, "Directory Does Not Exist, Create It", Toast.LENGTH_SHORT).show();
            success = storageDir.mkdir();
        }
        if (success) {
            //Toast.makeText(FormularioActivity.this, "Directory Created", Toast.LENGTH_SHORT).show();
        } else {
            //Toast.makeText(FormularioActivity.this, "Failed - Error", Toast.LENGTH_SHORT).show();
        }
        File image = File.createTempFile(
                _imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "file:" + image.getAbsolutePath();
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            if (Build.VERSION.SDK_INT > M) {
                Uri imageUri = Uri.parse(mCurrentPhotoPath);
                File file = new File(imageUri.getPath());
                try {
                    InputStream ims = new FileInputStream(file);
                    Bitmap imageBitmap = BitmapFactory.decodeStream(ims);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(90);
                    Bitmap bm_t_r = Bitmap.createBitmap(imageBitmap, 0, 0, imageBitmap.getWidth(), imageBitmap.getHeight(), matrix, true);
                    ivImage.setImageBitmap(bm_t_r);
                    ivImage.setVisibility(View.VISIBLE);
                    picture = true;

                } catch (FileNotFoundException e) {
                    return;
                }
            } else {
                if (Build.VERSION.SDK_INT >= JELLY_BEAN && Build.VERSION.SDK_INT <= KITKAT_WATCH) {
                    Bitmap bm_t = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(_imagefileUri.getPath()), 150, 200);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(90);
                    Bitmap bm_t_r = Bitmap.createBitmap(bm_t, 0, 0, bm_t.getWidth(), bm_t.getHeight(), matrix, true);
                    ivImage.setImageBitmap(bm_t_r);
                    ivImage.setVisibility(View.VISIBLE);
                } else {
                    Bitmap bm_t = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(_imagefileUri.getPath()), 150, 200);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(0);
                    Bitmap bm_t_r = Bitmap.createBitmap(bm_t, 0, 0, bm_t.getWidth(), bm_t.getHeight(), matrix, true);
                    ivImage.setImageBitmap(bm_t_r);
                    ivImage.setVisibility(View.VISIBLE);
                    picture = true;
                }
            }
        } else if (resultCode == RESULT_CANCELED) {
            // user cancelled Image capture
            Toast.makeText(getApplicationContext(),
                    "El usuario ha cancelado la captura de imagen", Toast.LENGTH_SHORT).show();
        } else {
            // failed to capture image
            Toast.makeText(getApplicationContext(),
                    "Error al tomar la imagen", Toast.LENGTH_SHORT)
                    .show();
        }
    }

    private void uploadImage(String picturePath) {
        if (Build.VERSION.SDK_INT > M) {
            Uri imageUri = Uri.parse(mCurrentPhotoPath);
            File file = new File(imageUri.getPath());
            try {
                InputStream ims = new FileInputStream(file);
                Bitmap bm_original = BitmapFactory.decodeStream(ims);
                Matrix matrix = new Matrix();
                matrix.postRotate(90);
                Bitmap bm = Bitmap.createBitmap(bm_original, 0, 0, bm_original.getWidth(), bm_original.getHeight(), matrix, true);
                // Pequeña transformación luego de capturar la imagen para que se redimensione a una resolucion de 960 pixeles
                final int maxSize = 960;
                int outWidth;
                int outHeight;
                int inWidth = bm.getWidth();
                int inHeight = bm.getHeight();
                if (inWidth > inHeight) {
                    outWidth = maxSize;
                    outHeight = (inHeight * maxSize) / inWidth;
                } else {
                    outHeight = maxSize;
                    outWidth = (inWidth * maxSize) / inHeight;
                }

                Bitmap resizedBitmap = Bitmap.createScaledBitmap(bm, outWidth, outHeight, false);


                //Aquí llamamos al asincrónico que sube los datos

                ByteArrayOutputStream bao = new ByteArrayOutputStream();
                resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bao);
                byte[] byteArray = bao.toByteArray();
                _bytes64Sting = Base64.encodeBytes(byteArray);
                RequestPackage rp = new RequestPackage();
                rp.setMethod("POST");
                rp.setUri(URL);
                rp.setSingleParam("base64", _bytes64Sting);
                rp.setSingleParam("ImageName", _imageFileName + ".jpg");
                new DoFileUpload(ReporteActivity.this, _imageFileName + ".jpg").execute(rp);
            } catch (FileNotFoundException e) {
                return;
            }
        } else {
            Bitmap bm = BitmapFactory.decodeFile(picturePath);
            // Pequeña transformación luego de capturar la imagen para que se redimencione a una resolucion de 960 pixeles
            final int maxSize = 960;
            int outWidth;
            int outHeight;
            int inWidth = bm.getWidth();
            int inHeight = bm.getHeight();
            if (inWidth > inHeight) {
                outWidth = maxSize;
                outHeight = (inHeight * maxSize) / inWidth;
            } else {
                outHeight = maxSize;
                outWidth = (inWidth * maxSize) / inHeight;
            }
            Bitmap resizedBitmap;
            if (Build.VERSION.SDK_INT >= JELLY_BEAN && Build.VERSION.SDK_INT <= KITKAT_WATCH) {
                Bitmap resizedBitmap_original = Bitmap.createScaledBitmap(bm, outWidth, outHeight, false);
                Matrix matrix = new Matrix();
                matrix.postRotate(90);
                resizedBitmap = Bitmap.createBitmap(resizedBitmap_original, 0, 0, resizedBitmap_original.getWidth(), resizedBitmap_original.getHeight(), matrix, true);
            } else {
                resizedBitmap = Bitmap.createScaledBitmap(bm, outWidth, outHeight, false);
            }


            ByteArrayOutputStream bao = new ByteArrayOutputStream();
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bao);
            byte[] byteArray = bao.toByteArray();
            _bytes64Sting = Base64.encodeBytes(byteArray);
            RequestPackage rp = new RequestPackage();
            rp.setMethod("POST");
            rp.setUri(URL);
            rp.setSingleParam("base64", _bytes64Sting);
            rp.setSingleParam("ImageName", _imageFileName + ".jpg");
            new DoFileUpload(ReporteActivity.this, _imageFileName + ".jpg").execute(rp);

        }
    }


//region - Estados del punto

    private File getFile() throws IOException {
        String filepath = Environment.getExternalStorageDirectory().getPath();
        file = new File(filepath, IMAGE_CAPTURE_FOLDER);
        if (!file.exists()) {
            file.mkdirs();
        }
        return new File(file + File.separator + _imageFileName
                + ".jpg");
    }

    private void sendData(String id_marcador, String id_tipo_marcador, String estado_marcador) {
        String correo;
        SharedPreferences preferences = getSharedPreferences("mypreferences", MODE_PRIVATE);
        correo = preferences.getString("correo", "");
        SendDataRequest sendDataRequest = new SendDataRequest(correo, id_marcador, id_tipo_marcador, estado_marcador);
        sendDataRequest.execute();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_photo:
                captureImage();    //método para sacar fotografía
                break;
            case R.id.button_siguiente_formulario:
                if (picture) {  // si se ha capturado una foto, continuamos
                    if (estado_contenedor != null) { // si el estado del contenedor no es null, continuamos
                        if (cd.isConnectingToInternet()) { // se comprueba la conexión a internet
                            if (cd.isConnectingToInternet()) {
                                sendData(marker_id, marker_type_id, estado_contenedor); //subimos los datos del punto
                                uploadImage(_imagefileUri.getPath()); // subimos la fotografía del punto
                                File dir = new File(Environment.getExternalStorageDirectory() + "/uploads");
                                //comprueba si es directorio.
                                if (dir.isDirectory()) {
                                    //obtiene un listado de los archivos contenidos en el directorio.
                                    String[] hijos = dir.list();
                                    //Elimina los archivos contenidos.
                                    for (int i = 0; i < hijos.length; i++) {
                                        new File(dir, hijos[i]).delete();
                                    }
                                }
                                finish();
                                Intent intent2 = new Intent(getApplicationContext(), MapActivity.class);
                                intent2.putExtra("plastico", pla); //enviamos estos datos a la MapActivity
                                intent2.putExtra("vidrio", vid);
                                intent2.putExtra("papelycarton", car);
                                intent2.putExtra("aluminio", alu);
                                intent2.putExtra("reciclaje", reciclaje); //
                                intent2.putExtra("gracias", true);
                                startActivity(intent2);

                            } else {
                                Toast.makeText(ReporteActivity.this, "NO hay conexión a internet..", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(ReporteActivity.this, "No hay conexión a internet !", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(ReporteActivity.this, "Debe seleccionar un estado", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(ReporteActivity.this, "Debe adjuntar una fotografía", Toast.LENGTH_LONG).show();
                }
                break;

        }
    }

    //endregion
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_REQUEST_CODE: {
                if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, woho!
                } else {
                    Intent intent = new Intent(getApplicationContext(), ReporteActivity.class);
                    finish();
                    startActivity(intent);
                }
                return;
            }
        }


    }

    public class SendDataRequest extends AsyncTask<String, String, String> {

        private final String USER_AGENT = "Mozilla/5.0";
        private String id_marcador = "";
        private String id_tipo_marcador = "";
        private String estado_marcador = "";
        private String correo_persona = "";
        private Object json_decode;
        private Boolean result = false;

        public SendDataRequest(String correo, String id_marcador, String id_tipo_marcador, String estado_marcador) {
            this.id_marcador = id_marcador;
            this.id_tipo_marcador = id_tipo_marcador;
            this.estado_marcador = estado_marcador;
            this.correo_persona = correo;
        }

        @Override
        protected String doInBackground(String... params) {
            //Enviar los datos aquí
            try {
                this.json_decode = POST(SEVER_URL, "id_punto=".concat(this.id_marcador.concat("&tipo_punto=".concat(this.id_tipo_marcador.concat("&estado_contenedor=".concat(this.estado_marcador.concat("&correo=".concat(this.correo_persona))))))));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private String POST(String url, String urlParameters) throws IOException {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            //add request header
            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

//            String urlParameters = "sn=C02G8416DRJM&cn=&locale=&caller=&num=12345";

            // Send post request
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result
            return (response.toString());

        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
        }
    }


}

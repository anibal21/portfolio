package com.ideas.autumn.greencity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.ideas.autumn.greencity.Beneficios.BeneficiosActivity;
import com.ideas.autumn.greencity.Modelo.IdMarcadoresList;
import com.ideas.autumn.greencity.Modelo.MarcadoresJSON;
import com.ideas.autumn.greencity.Modelo.UserStatusRequest;
import com.ideas.autumn.greencity.Popup.Popup_Gracias;
import com.ideas.autumn.greencity.Popup.Popup_Map1;
import com.ideas.autumn.greencity.Reporte.ReporteActivity;
import com.ideas.autumn.greencity.Sesion.OpcionesActivity;
import com.ideas.autumn.greencity.Sesion.PreLoginActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.ideas.autumn.greencity.Modelo.RealPathUtil.getPath;
import static java.lang.Math.abs;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, NavigationView.OnNavigationItemSelectedListener {

    public static final String SERVER_URL = "https://www.autumnideas.com/greenmate/getMarkers.php";
    public static final String SERVER_URL_REQUEST = "https://www.autumnideas.com/greenmate/setReport.php";
    static final int PICK_IMAGE = 100;
    GoogleMap mGoogleMap;
    LocationRequest mLocationRequest;  //creamos una solicitud para la locacion del usuario
    GoogleApiClient mGoogleApiClient;
    LocationManager locationManager;
    LocationListener locationListener;
    Location lastKnowLocation;
    LatLng mylocation;
    String correo, path1;
    double userlatitud, userlongitud;
    Boolean pla = true;
    Boolean vid = true;
    Boolean car = true;
    Boolean alu = true;
    Boolean reciclaje = false;  // señaliza de qué activity viene el usuario
    Boolean radio = false;
    Boolean gracias = false;
    String type, status;
    int icon;
    Uri imageUri;
    CircleImageView imgProfile;
    ArrayList<MarcadoresJSON> marcadoresJSON = new ArrayList<>();
    ArrayList<IdMarcadoresList> idMarcadoresList = new ArrayList<>();


    //manejamos los resultados de la solicitud de permisos para el usuario
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                Location lastKnowLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);// la idea es que la locación se dé cuando el mapa ya está desplegado.
                if (lastKnowLocation != null) {
                    LatLng userLocation = new LatLng(lastKnowLocation.getLatitude(), lastKnowLocation.getLongitude());
                    mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 17));
                }
            }
            mGoogleMap.setMyLocationEnabled(true);
        }
    }

    private void permission() {
        if (Build.VERSION.SDK_INT < 23) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            lastKnowLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastKnowLocation != null) {
                LatLng userLocation = new LatLng(lastKnowLocation.getLatitude(), lastKnowLocation.getLongitude());
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 17));
            }
            mGoogleMap.setMyLocationEnabled(true);

        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // preguntamos por los permisos
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

            } else {
                // tenemos permisos!
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                lastKnowLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                mGoogleMap.setMyLocationEnabled(true);
                if (lastKnowLocation != null) {
                    LatLng userLocation = new LatLng(lastKnowLocation.getLatitude(), lastKnowLocation.getLongitude());
                    mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 17));
                }
            }

        }
    }

    public void setPreferences() {       //Método para recordar que el usuario ya ha realizado un login
        SharedPreferences preferences = getSharedPreferences("mypreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        correo = preferences.getString("correo", "");
        editor.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        setPreferences();
        // Elementos del Map Drawer
        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        userStatusRequest(drawer, correo);  // lo hacemos antes de que se abra el drawer!
        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar); //Elemento de Drawer
        setSupportActionBar(toolbar); //Elemento de Drawer

        // Botón redondo a la derecha y abajo
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.hide();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                userStatusRequest(drawer, correo);// al abrir el drawer, si hay modificaciones en los puntajes se mostrarán
            }
        };
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Bundle bundle = getIntent().getExtras();     //--cambios ale---- Acá recibimos la información de los checkbox--
        if (bundle != null) {
            pla = bundle.getBoolean("plastico");
            vid = bundle.getBoolean("vidrio");
            car = bundle.getBoolean("papelycarton");
            alu = bundle.getBoolean("aluminio");
            reciclaje = bundle.getBoolean("reciclaje");
            gracias = bundle.getBoolean("gracias");
        }

        // Se agrega código para cambiar la imagen de perfil
        View header = navigationView.getHeaderView(0);
        SharedPreferences preferences2 = getSharedPreferences("preferences", MODE_PRIVATE); // vemos si la foto de perfil está guardada en memoria
        String backuri = preferences2.getString("uri", null); //sacamos el path desde SharedPreferences

        if (backuri != null) {
            imgProfile = (CircleImageView) header.findViewById(R.id.profile_image);
            if (Build.VERSION.SDK_INT < 23) {
                Uri uri = Uri.parse(backuri);
                String path = getPath(getApplicationContext(), uri);
                Bitmap bitmap = BitmapFactory.decodeFile(path);
                imgProfile.setImageBitmap(bitmap);
            } else {
                Uri uri = Uri.parse(backuri);
                //Toast.makeText(getApplicationContext(),"Sacamos el Uri del preference:"+uri,Toast.LENGTH_LONG).show();
                imgProfile.setImageURI(uri);

            }

        } else {
            imgProfile = (CircleImageView) header.findViewById(R.id.profile_image); // si no hay uri guardada en memoria, el perfil quedará con la foto por defecto.
            imgProfile.setImageResource(R.drawable.photo_profile);
        }

        imgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {    // si se presiona la foto de perfil, elegimos una foto de la galería
                Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                startActivityForResult(gallery, PICK_IMAGE);


            }
        });
        setPreferences();
        initMap();
        Popup_Gracias();  // popup gracias

    }

    public void Popup_Gracias() {
        if (gracias) {
            Intent intent = new Intent(getApplicationContext(), Popup_Gracias.class);
            startActivity(intent);
            gracias = false;
        }

    }

    @Override
    protected void onActivityResult(int RequestCode, int ResultCode, Intent data) {
        super.onActivityResult(RequestCode, ResultCode, data);
        if (ResultCode == RESULT_OK && RequestCode == PICK_IMAGE) {
            imageUri = data.getData();  // si se elige una foto de la galería, ésta queda como foto de perfil
            imgProfile.setImageURI(imageUri);
            Preferences();   //se guarda el Uri en memoria con el método Preferences()
        }
    }


    private void initMap() {
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapFragment);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void Preferences() {

        if (imageUri != null) {
            SharedPreferences preferences2 = getSharedPreferences("preferences", Context.MODE_PRIVATE); // guardamos la Uri de la foto de perfil
            SharedPreferences.Editor editor = preferences2.edit();
            editor.putString("uri", imageUri.toString());
            //Toast.makeText(getApplicationContext(),"path guardado: "+imageUri.toString(),Toast.LENGTH_LONG).show();
            editor.commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return false; //False para que no salgan los puntos en el action bar
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onMapReady(GoogleMap map) {

        //se hace trabajar el location manager dentro del mapa ya desplegado!
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {

            @Override
            public void onLocationChanged(Location location) {
                mylocation = new LatLng(location.getLatitude(), location.getLongitude());
                userlatitud = mylocation.latitude;
                userlongitud = mylocation.longitude;
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };
        mGoogleMap = map;
        permission();

        //usamos la información de la locación de usuario
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();     //nos conectamos con la api para saber sobre la locación del usuario


        //Espacio para que la ActionBar no tape el boton de GPS
        int padding_in_dp = 55;  // 55 dps
        final float scale = getResources().getDisplayMetrics().density;
        int padding_in_px = (int) (padding_in_dp * scale + 0.5f);
        map.setPadding(0, padding_in_px, 0, 0); //Esta propiedad solo acepta pixeles, por eso se pasa de dp a pixeles

        //Marcadores
        loadMarkersLoop();

    }

    private void loadMarkersLoop() {
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                DownloadJSONMarkers downloadJSON = new DownloadJSONMarkers();
                downloadJSON.execute();
            }
        }, 0, 10000);//put here time 10000 milliseconds=10 second
    }

    private void chargeMarkersInfo(String database_marker_id) {
        MarkersJSONRequest markersJSONRequest = new MarkersJSONRequest(database_marker_id);
        markersJSONRequest.execute();
    }

    @Override
    public void onConnected(Bundle bundle) {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(1000);    //pedimos información  cada un segundo */
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    //Acciones del Navigation Drawer
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_end_session) {
            //probamos el LOGOUT!
            SharedPreferences preferences = getSharedPreferences("mypreferences", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.remove("contrasena");
            editor.commit();
            Intent intent1 = new Intent(getApplicationContext(), PreLoginActivity.class);
            finish();
            startActivity(intent1);
        } else if (id == R.id.nav_opcion) {   // hay que probar los finish() para ver que sucede con la foto de perfil
            Intent intent2 = new Intent(getApplicationContext(), OpcionesActivity.class);
            //finish();
            startActivity(intent2);
        } else if (id == R.id.nav_canje) {
            // finish();
            Intent intent = new Intent(getApplicationContext(), BeneficiosActivity.class);
            intent.putExtra("plastico", pla); //enviamos estos datos a la Beneficios
            intent.putExtra("vidrio", vid);
            intent.putExtra("papelycarton", car);
            intent.putExtra("aluminio", alu);
            intent.putExtra("reciclaje", reciclaje);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void userStatusRequest(DrawerLayout drawer, String correo) {
        UserStatusRequest UserStatusRequest = new UserStatusRequest(drawer, correo);
        UserStatusRequest.execute();
    }

    public int iconMarkers(String type, String status) {
        //contenedor tipo reciclaje (aluminio/pilas?)
        if (type.equals("4")) {
            if ((status.equals("-1")) && (alu)) {   //vacio
                int icon = R.drawable.iconosmapa_pilas;
                return icon;
            }
            if ((status.equals("0")) && (alu)) {    //medio
                int icon = R.drawable.iconosmapa_pilas;
                return icon;
            }
            if ((status.equals("1")) && (alu) && (!reciclaje)) {   //lleno
                int icon = R.drawable.iconosmapa_pilas;
                return icon;
            }
            if ((status.equals("2")) && (alu) && (!reciclaje)) {   //desaparecido
                int icon = R.drawable.iconosmapa_pilas;
                return icon;
            }
        }

        // contenedor tipo vidrio
        if (type.equals("2")) {
            if ((status.equals("-1")) && (vid)) {   //vacio
                int icon = R.drawable.iconosmapa_vidrio;
                return icon;
            }
            if ((status.equals("0")) && (vid)) {    //medio
                int icon = R.drawable.iconosmapa_vidrio;
                return icon;
            }
            if ((status.equals("1")) && (vid) && (!reciclaje)) {   //lleno
                int icon = R.drawable.iconosmapa_vidrio;
                return icon;
            }
            if ((status.equals("2")) && (vid) && (!reciclaje)) {   //desaparecido
                int icon = R.drawable.iconosmapa_vidrio;
                return icon;
            }
        }
        //contenedor de plastico
        if (type.equals("1")) {
            if ((status.equals("-1")) && (pla)) {   //vacio
                int icon = R.drawable.iconosmapa_plastico;
                return icon;
            }
            if ((status.equals("0")) && (pla)) {    //medio
                int icon = R.drawable.iconosmapa_plastico;
                return icon;
            }
            if ((status.equals("1")) && (pla) && (!reciclaje)) {   //lleno
                int icon = R.drawable.iconosmapa_plastico;
                return icon;
            }
            if ((status.equals("2")) && (pla) && (!reciclaje)) {   //desaparecido
                int icon = R.drawable.iconosmapa_plastico;
                return icon;
            }
        }

        //contenedor tipo reciclaje (papel y carton)
        if (type.equals("3")) {
            if ((status.equals("-1")) && (car)) {   //vacio
                int icon = R.drawable.iconosmapa_papel;
                return icon;
            }
            if ((status.equals("0")) && (car)) {    //medio
                int icon = R.drawable.iconosmapa_papel;
                return icon;
            }
            if ((status.equals("1")) && (car) && (!reciclaje)) {   //lleno
                int icon = R.drawable.iconosmapa_papel;
                return icon;
            }
            if (status.equals("2") && (car) && (!reciclaje)) {   //desaparecido
                int icon = R.drawable.iconosmapa_papel;
                return icon;
            }
        }


        // contenedor tipo basurero
        if ((type.equals("5")) && (pla) && (vid) && (car) && (alu) && (!reciclaje)) {
            if (status.equals("-1")) {   //vacio
                int icon = R.drawable.iconosmapa_basurero_vacio;
                return icon;
            }
            if (status.equals("0")) {    //medio
                int icon = R.drawable.iconosmapa_basurero_medio;
                return icon;
            }
            if (status.equals("1")) {   //lleno
                int icon = R.drawable.iconosmapa_basurero_lleno;
                return icon;
            }
            if (status.equals("2")) {   //desaparecido
                int icon = R.drawable.iconosmapa_basurero_lleno;
                return icon;
            }
        }


        return 0;
    }

    public class DownloadJSONMarkers extends AsyncTask<Void, Void, Void> {

        //Método inicial de la clase
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                URL theUrl = new URL(SERVER_URL);
                BufferedReader reader = new BufferedReader(new InputStreamReader(theUrl.openConnection().getInputStream(), "UTF-8"));
                String jsonString = reader.readLine();

                JSONArray allObj = new JSONArray(jsonString);
                JSONObject dataObj = allObj.getJSONObject(0);
                JSONArray markers = dataObj.getJSONArray("query");

                for (int i = 0; i < markers.length(); i++) {
                    JSONObject marker1Obj = markers.getJSONObject(i);
                    MarcadoresJSON temp = new MarcadoresJSON(marker1Obj.getString("title"), marker1Obj.getString("snippet"), marker1Obj.getString("lat"), marker1Obj.getString("lon"), marker1Obj.getString("id"), marker1Obj.getString("type"), marker1Obj.getString("status"));
                    marcadoresJSON.add(temp);
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        //Método que ocurre luego de que DoInBackground se haya completado
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            mGoogleMap.clear();
            idMarcadoresList.clear();
            for (int i = 0; i < marcadoresJSON.size(); i++) {
                Double latitude = Double.parseDouble(marcadoresJSON.get(i).getLat());
                Double longitude = Double.parseDouble(marcadoresJSON.get(i).getLon());
                LatLng llObj = new LatLng(latitude, longitude);
                type = marcadoresJSON.get(i).getType();
                status = marcadoresJSON.get(i).getStatus();
                icon = iconMarkers(type, status);   //método que devuelve el ícono correcto.
                if (icon != 0) { // si el ícono no es vacío se pone el marcador en el mapa
                    Marker marker = mGoogleMap.addMarker(new MarkerOptions()
                            .title(marcadoresJSON.get(i).getTitle())
                            .snippet(marcadoresJSON.get(i).getSnippet())
                            .position(llObj)
                            .icon(BitmapDescriptorFactory.fromResource(icon)));

                    IdMarcadoresList temp1 = new IdMarcadoresList(marcadoresJSON.get(i).getId(), marker.getId());
                    idMarcadoresList.add(temp1);
                }
                mGoogleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                    @Override
                    public void onInfoWindowClick(Marker marker) {
                        String database_marker_id = "";
                        for (int j = 0; j < idMarcadoresList.size(); j++) {
                            if (idMarcadoresList.get(j).getIdGm().equals(marker.getId())) {
                                double latfinal = marker.getPosition().latitude;       // le devolvemos el punto decimal a los números.
                                double lonfinal = marker.getPosition().longitude;
                                // Probamos si el contenedor está dentro del cuadrante del usuario (cuadrante aproximada de 10 metros de lado, centrado en el usuario)
                                // if(true){
                                if (userlatitud == 0 || userlongitud == 0) {
                                    Toast.makeText(getApplicationContext(), "No es posible encontrar la ubicación del usuario", Toast.LENGTH_SHORT).show();
                                } else if (((abs(userlatitud - latfinal)) < 0.0005) && ((abs(userlongitud - lonfinal)) < 0.0005)) {

                                    database_marker_id = idMarcadoresList.get(j).getIdBD();
                                    chargeMarkersInfo(database_marker_id);
                                    radio = true;
                                } else {

                                    database_marker_id = idMarcadoresList.get(j).getIdBD();
                                    chargeMarkersInfo(database_marker_id);

                                }


                            }
                        }
                    }
                });
            }
            marcadoresJSON.clear();

        }
    }

    public class MarkersJSONRequest extends AsyncTask<Void, Void, Void> {

        private final String USER_AGENT = "Mozilla/5.0";
        private String id_marker;
        private String json_decoded;
        private String marker_title = "";
        private String marker_snippet = "";
        private String marker_name = "";
        private String marker_type_id = "";
        private String marker_status = "";

        public MarkersJSONRequest(String id_marker) {
            this.id_marker = id_marker;
        }

        @Override
        protected Void doInBackground(Void... voids) {

            try {
                this.json_decoded = POST(SERVER_URL_REQUEST, "id_marker=".concat(this.id_marker));
            } catch (IOException e) {
                e.printStackTrace();
            }

            String jsonString = this.json_decoded;

            JSONArray allObj = null;
            try {
                allObj = new JSONArray(jsonString);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            JSONObject dataObj = null;
            try {
                dataObj = allObj.getJSONObject(0);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            JSONArray markers = null;
            try {
                markers = dataObj.getJSONArray("query");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            for (int i = 0; i < markers.length(); i++) {
                JSONObject marker1Obj = null;
                try {
                    marker1Obj = markers.getJSONObject(i);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    this.marker_title = marker1Obj.getString("title");
                    this.marker_snippet = marker1Obj.getString("snippet");
                    this.marker_name = marker1Obj.getString("nombre");
                    this.marker_type_id = marker1Obj.getString("id_tipo_marcador");
                    this.marker_status = marker1Obj.getString("id_estado");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        private String POST(String url, String urlParameters) throws IOException {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            //add reuqest header
            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

//            String urlParameters = "sn=C02G8416DRJM&cn=&locale=&caller=&num=12345";

            // Send post request
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result
            return (response.toString());

        }

        @Override
        protected void onPostExecute(Void aVoid) {

            if (radio) {   //si está en el radio, podemos reportar
                Intent intent2 = new Intent(getApplicationContext(), ReporteActivity.class);
                intent2.putExtra("marker_title", this.marker_title);
                intent2.putExtra("marker_snippet", this.marker_snippet);
                intent2.putExtra("marker_name", this.marker_name);
                intent2.putExtra("marker_type_id", this.marker_type_id);
                intent2.putExtra("marker_id", this.id_marker);
                intent2.putExtra("plastico", pla); //enviamos estos datos al ReporteActivity
                intent2.putExtra("vidrio", vid);
                intent2.putExtra("papelycarton", car);
                intent2.putExtra("aluminio", alu);
                intent2.putExtra("reciclaje", reciclaje);


                startActivity(intent2);
            } else {   // si no está en el radio, vemos el Popup_Map1

                Intent intent = new Intent(MapActivity.this, Popup_Map1.class);
                intent.putExtra("marker_title", this.marker_title);
                intent.putExtra("marker_snippet", this.marker_snippet);
                intent.putExtra("marker_name", this.marker_name);
                intent.putExtra("marker_type_id", this.marker_type_id);
                intent.putExtra("marker_id", this.id_marker);
                intent.putExtra("marker_status", this.marker_status);  //estado del punto (vacio,medio, lleno)
                startActivity(intent);


            }

        }
    }


}
